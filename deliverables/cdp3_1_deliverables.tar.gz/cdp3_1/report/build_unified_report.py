"""
Build unified change report (Phase 1 + Phase 2) in Word format (English + Chinese).
Covers all changes from the initial state to final state for the CDP 3.5.2/3.5.3
row_source fixed-row scoring implementation.

Run: python AIESG/cdp3_1/report/build_unified_report.py
"""

from docx import Document
from docx.shared import Pt
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT
import os

OUTPUT_DIR = os.path.dirname(os.path.abspath(__file__))


def set_cell_text(cell, text, bold=False, size=9):
    cell.text = ""
    p = cell.paragraphs[0]
    run = p.add_run(text)
    run.font.size = Pt(size)
    run.font.name = "Calibri"
    if bold:
        run.bold = True


def add_table(doc, headers, rows):
    table = doc.add_table(rows=1 + len(rows), cols=len(headers))
    table.style = "Table Grid"
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    for i, h in enumerate(headers):
        set_cell_text(table.rows[0].cells[i], h, bold=True)
        table.rows[0].cells[i].paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER
    for r_idx, row in enumerate(rows):
        for c_idx, val in enumerate(row):
            set_cell_text(table.rows[r_idx + 1].cells[c_idx], str(val))
    return table


def add_code_block(doc, code):
    p = doc.add_paragraph(style="No Spacing")
    run = p.add_run(code)
    run.font.size = Pt(8.5)
    run.font.name = "Consolas"


# =============================================================================
# ENGLISH
# =============================================================================
def build_en(path):
    doc = Document()
    style = doc.styles["Normal"]
    style.font.name = "Calibri"
    style.font.size = Pt(10)

    doc.add_heading(
        "Unified Change Report\n"
        "CDP 3.5.2 / 3.5.3 Fixed-Row Scoring — Full Implementation",
        level=1,
    )

    p = doc.add_paragraph()
    p.add_run("Date: ").bold = True
    p.add_run("2026-03-08\n")
    p.add_run("Scope: ").bold = True
    p.add_run("Scoring groups 3.5.2 (Emissions Trading Systems) and 3.5.3 (Carbon Tax)\n")
    p.add_run("Goal: ").bold = True
    p.add_run(
        'Implement "fixed rows populated by parent question selection" — the number of '
        "expected rows in 3.5.2/3.5.3 is determined by the answers to parent question 3.5.1.1; "
        "any expected row not submitted receives a score of zero. The implementation spans the "
        "full stack: spreadsheet metadata, compiler pipeline, scoring functions, API schemas, "
        "dependency propagation, answer utilities, tests, and documentation."
    )

    # =========================================================================
    doc.add_heading("1. Problem Statement", level=2)
    doc.add_paragraph(
        "CDP questionnaire groups 3.5.2 (ETS details) and 3.5.3 (carbon tax details) are "
        "multi-row tables. Each row corresponds to a carbon pricing system selected by the "
        "respondent in question 3.5.1.1. The original codebase had no mechanism to:"
    )
    bullets = [
        "Know that 3.5.2/3.5.3 are row-based groups (the spreadsheet metadata was missing)",
        "Determine how many rows are expected based on 3.5.1.1 selections",
        "Penalize missing rows in the disclosure score",
        "Scale awareness/management/leadership scores proportionally",
        "Accept row-prefixed answer keys through the API schema layer",
        "Propagate the sibling dependency (3.5.1.1) so scoring functions receive it",
    ]
    for b in bullets:
        doc.add_paragraph(b, style="List Bullet")
    doc.add_paragraph(
        "As a result, a company selecting 3 ETS systems in 3.5.1.1 but submitting only 1 row "
        "of detail in 3.5.2 received the same score as one submitting all 3 rows. Additionally, "
        "a condition_parser bug caused all sub-questions within 3.5.2/3.5.3 to be evaluated as "
        "invisible, meaning the grouping question alone received full marks."
    )

    # =========================================================================
    doc.add_heading("2. All Modified and New Files", level=2)
    add_table(
        doc,
        ["#", "File", "Type", "Nature of Change"],
        [
            ["1", "cdp3_1-main/CDP_scoring_questions.xlsx", "Modified",
             "Added row_source column; changed question_type to multi-row; cleared 15 broken conditional_on values"],
            ["2", "cdp3_1-main/backend/compiler/compiler_config.py", "Modified",
             "Added row_source field to QuestionSpec dataclass"],
            ["3", "cdp3_1-main/backend/compiler/spreadsheet_parser.py", "Modified",
             "Added row_source reading; added row_source detection in is_row_based_scoring_group()"],
            ["4", "cdp3_1-main/backend/compiler/scoring_rules/generators/multi_row/main.py", "Modified",
             "Fixed empty-row return type; added _build_row_source_penalty(); added _build_row_source_category_scaling()"],
            ["5", "cdp3_1-main/backend/compiler/scoring_rules/template_builder.py", "Modified",
             "Added ROW_SOURCE_DEP_QUESTION constant generation"],
            ["6", "cdp3_1-main/backend/compiler/schema_generator.py", "Modified",
             "is_multi_row detection now includes row_source; dependency generation adds row_source sibling deps to GROUP_DEPENDENCIES"],
            ["7", "cdp3_1-main/backend/scoring/scoring_group_3_5_2.py", "Re-generated",
             "Auto-regenerated by compiler; reflects all compiler changes"],
            ["8", "cdp3_1-main/backend/scoring/scoring_group_3_5_3.py", "Re-generated",
             "Auto-regenerated by compiler; reflects all compiler changes"],
            ["9", "cdp3_1-main/backend/api/schemas/groups/group_3_5_2.py", "Modified",
             'extra: "forbid" -> "allow"; GROUP_DEPENDENCIES adds 3.5.1.1 sibling dep'],
            ["10", "cdp3_1-main/backend/api/schemas/groups/group_3_5_3.py", "Modified",
             "Same as group_3_5_2.py"],
            ["11", "cdp3_1-main/backend/api/answer_utils.py", "Modified",
             "New get_sibling_dependencies(); prepare_answers_for_scoring() injects sibling deps"],
            ["12", "cdp3_1-main/backend/api/test_requests/TESTING_GUIDE.md", "Modified",
             "Added row_source sibling dependency section with request examples"],
            ["13", "cdp3_1-main/backend/tests/questions/test_scoring_3_5_2.py", "New",
             "8 tests: schema, dependency, scoring penalty, answer_utils, stateless behavior"],
            ["14", "cdp3_1-main/backend/tests/questions/test_scoring_3_5_3.py", "New",
             "5 tests: schema, dependency, scoring penalty"],
        ],
    )

    # =========================================================================
    doc.add_heading("3. Change Details", level=2)

    # --- 3.1 ---
    doc.add_heading("3.1 Spreadsheet: row_source metadata and question_type", level=3)
    doc.add_paragraph("File: cdp3_1-main/CDP_scoring_questions.xlsx")
    add_table(
        doc,
        ["Question", "Column", "Original", "Final"],
        [
            ["3.5.2.0", "question_type", "classification", "multi-row"],
            ["3.5.2.0", "classification_options", "(empty)",
             '{"type":"multi-row","options":[],"question_type":"multi-row"}'],
            ["3.5.2.0", "row_source", "(column did not exist)", "3.5.1.1:contains=ETS"],
            ["3.5.3.0", "question_type", "classification", "multi-row"],
            ["3.5.3.0", "classification_options", "(empty)",
             '{"type":"multi-row","options":[],"question_type":"multi-row"}'],
            ["3.5.3.0", "row_source", "(column did not exist)", "3.5.1.1:contains=tax"],
        ],
    )
    doc.add_paragraph(
        "Why: The compiler routes a scoring group to FixedRowsMainGenerator only when "
        "question_type='multi-row'. The row_source field encodes which parent question and "
        "keyword filter determine expected rows. Without these, the compiler produces flat "
        "(non-row-based) scoring logic with no row iteration."
    )

    # --- 3.2 ---
    doc.add_heading("3.2 Spreadsheet: Clear 15 broken conditional_on values", level=3)
    doc.add_paragraph("File: cdp3_1-main/CDP_scoring_questions.xlsx")
    doc.add_paragraph(
        "Questions 3.5.2.1-3.5.2.10 (10 rows): conditional_on was '3.5.0.1 != NULL' -> cleared.\n"
        "Questions 3.5.3.1-3.5.3.5 (5 rows): various conditional_on values -> cleared."
    )
    doc.add_paragraph(
        "Why: condition_parser.py has a structural bug. When conditional_on references a "
        "flat-group question (3.5.0.1 in group 3.5), it generates:"
    )
    add_code_block(doc, "any(_key.startswith('3.5.Row') for _key in answers)")
    doc.add_paragraph(
        "But actual keys in 3.5.2 are '3.5.2.Row N.3.5.2.Y' — the prefix '3.5.Row' never "
        "matches. All 10 sub-questions are evaluated as invisible; only the grouping question "
        "(3.5.2.0) is scored, giving full marks for answering just the system name. "
        "For fixed-row groups, sub-questions within a row are unconditionally visible once the "
        "row exists. Clearing the conditions removes the broken check entirely."
    )

    # --- 3.3 ---
    doc.add_heading("3.3 Compiler: QuestionSpec.row_source field", level=3)
    doc.add_paragraph("File: cdp3_1-main/backend/compiler/compiler_config.py")
    doc.add_paragraph("Added:")
    add_code_block(doc,
        "# Row source: specifies which parent question's answers determine the rows\n"
        "# Format: \"parent_question_num\" or \"parent_question_num:contains=keyword\"\n"
        "row_source: Optional[str] = None"
    )
    doc.add_paragraph(
        "Why: Without this field, the row_source value read from Excel has nowhere to be "
        "stored and is silently discarded before reaching any generator."
    )

    # --- 3.4 ---
    doc.add_heading("3.4 Compiler: Spreadsheet parser — row_source reading and detection", level=3)
    doc.add_paragraph("File: cdp3_1-main/backend/compiler/spreadsheet_parser.py")
    doc.add_paragraph(
        "A) Added row_source=get_value('row_source') to _parse_row() so the Excel column "
        "is read into QuestionSpec.\n\n"
        "B) Added a row_source check in is_row_based_scoring_group() between the existing "
        "question_type check and the conditional_on pattern check:"
    )
    add_code_block(doc,
        "# Check if the first question has row_source (fixed rows populated by parent question)\n"
        "if first_question.row_source:\n"
        "    return True"
    )
    doc.add_paragraph(
        "Why: (A) Without reading the column, row_source is always None. "
        "(B) This function decides whether the compiler routes to the row-based generator. "
        "Groups with row_source may not have the conditional_on patterns the original detection "
        "relied on."
    )

    # --- 3.5 ---
    doc.add_heading("3.5 Compiler: Empty-row return type fix", level=3)
    doc.add_paragraph("File: cdp3_1-main/backend/compiler/scoring_rules/generators/multi_row/main.py")
    doc.add_paragraph("Original generated code:")
    add_code_block(doc, "if not rows:\n    return {}")
    doc.add_paragraph("Final generated code:")
    add_code_block(doc,
        "if not rows:\n"
        "    from collections import defaultdict\n"
        "    return ({'disclosure': 0.0, 'awareness': 0.0, 'management': 0.0,\n"
        "             'leadership': 0.0}, defaultdict(list))"
    )
    doc.add_paragraph(
        "Why: Every scoring function must return a (scores_dict, tracking_dict) tuple. "
        "Returning bare {} causes TypeError when the API layer tries to unpack it."
    )

    # --- 3.6 ---
    doc.add_heading("3.6 Compiler: Row-source penalty for missing rows", level=3)
    doc.add_paragraph("File: cdp3_1-main/backend/compiler/scoring_rules/generators/multi_row/main.py")
    doc.add_paragraph(
        "New method _build_row_source_penalty() generates runtime code that:"
    )
    bullets = [
        "Reads the parent question answer (e.g., answers.get('3.5.1.1'))",
        "Filters by keyword (e.g., 'ets' or 'tax') to produce the expected row list",
        "Computes _rs_missing = max(0, expected - submitted)",
        "Appends 0.0 to group_disclosure_scores for each missing row",
        "Computes _rs_actual_ratio = min(1.0, submitted/expected), capped at 1.0",
        "Adds tracking entries for each missing row with reason 'Row expected from parent question but not submitted'",
    ]
    for b in bullets:
        doc.add_paragraph(b, style="List Bullet")
    doc.add_paragraph(
        "Why: Without this, avg_disclosure used len(submitted_rows) as denominator instead of "
        "len(expected_rows). A company submitting 1 of 3 expected rows got the same disclosure "
        "score as one submitting all 3."
    )

    # --- 3.7 ---
    doc.add_heading("3.7 Compiler: Category scaling for missing rows", level=3)
    doc.add_paragraph("File: cdp3_1-main/backend/compiler/scoring_rules/generators/multi_row/main.py")
    doc.add_paragraph("New method _build_row_source_category_scaling() generates:")
    add_code_block(doc,
        "group_awareness = group_awareness * _rs_actual_ratio\n"
        "group_management = group_management * _rs_actual_ratio\n"
        "group_leadership = group_leadership * _rs_actual_ratio"
    )
    doc.add_paragraph(
        "Why: Without this, awareness/management/leadership were scored from all submitted rows "
        "combined with no adjustment for missing rows. If 3 expected and 1 submitted: disclosure "
        "was correctly penalized (1/3) but awareness got full credit — an inconsistency. "
        "Multiplying by _rs_actual_ratio (capped at 1.0) ensures all four categories are "
        "proportionally penalized."
    )

    # --- 3.8 ---
    doc.add_heading("3.8 Compiler: ROW_SOURCE_DEP_QUESTION constant", level=3)
    doc.add_paragraph("File: cdp3_1-main/backend/compiler/scoring_rules/template_builder.py")
    doc.add_paragraph(
        "New code in build_scoring_file() scans questions for row_source and generates a "
        "module-level constant in each scoring file:"
    )
    add_code_block(doc,
        "# Sibling question required for row_source penalty scoring.\n"
        "# Include this question's answer in the API payload when scoring 3.5.2.\n"
        "ROW_SOURCE_DEP_QUESTION = '3.5.1.1'"
    )
    doc.add_paragraph(
        "Why: The scoring function reads answers.get('3.5.1.1') at runtime. If the caller "
        "omits it, the penalty is silently skipped with no error. This constant provides "
        "discoverability for API consumers and enables future auto-fill logic. Hard API "
        "enforcement (HTTP 422) was rejected because 3.5.1.1 may legitimately be absent for "
        "companies without carbon pricing exposure."
    )

    # --- 3.9 ---
    doc.add_heading("3.9 Schema generator: is_multi_row and dependency generation", level=3)
    doc.add_paragraph("File: cdp3_1-main/backend/compiler/schema_generator.py")
    doc.add_paragraph("A) is_multi_row detection — original:")
    add_code_block(doc,
        'is_multi_row = any(\n'
        '    q.question_type and "multi-row" in q.question_type.lower()\n'
        '    for q in questions\n'
        ')'
    )
    doc.add_paragraph("Final:")
    add_code_block(doc,
        'is_multi_row = any(\n'
        '    (q.question_type and "multi-row" in q.question_type.lower())\n'
        '    or getattr(q, \'row_source\', None)\n'
        '    for q in questions\n'
        ')'
    )
    doc.add_paragraph(
        "B) Dependency generation: after the existing field dependency loop, new code inspects "
        "each question's row_source. If set, extracts the parent question number and source "
        'group, appends a field dependency with reason="row_source" to GROUP_DEPENDENCIES.'
    )
    doc.add_paragraph(
        "Why: (A) Groups using row_source were not detected as multi-row, causing "
        'extra: "forbid" in schemas — rejecting row-prefixed payload keys. '
        "(B) Without this, recompiling would lose the sibling dependency declaration."
    )

    # --- 3.10 ---
    doc.add_heading("3.10 API schemas: extra policy and sibling dependency", level=3)
    doc.add_paragraph("Files: cdp3_1-main/backend/api/schemas/groups/group_3_5_2.py, group_3_5_3.py")
    add_table(
        doc,
        ["Attribute", "Original", "Final"],
        [
            ['model_config["extra"]', '"forbid"', '"allow"'],
            ["GROUP_DEPENDENCIES.fields", "Only 3.5.0.1 (conditional_on)",
             "3.5.0.1 (conditional_on) + 3.5.1.1 (row_source, source_group: 3.5.1)"],
        ],
    )
    doc.add_paragraph(
        'Why: "forbid" rejected row-prefixed keys like "3.5.2.Row 1.3.5.2.1", making the '
        "schema-validated /score endpoint unusable for multi-row submissions. "
        "group_7_30_16.py (another multi-row group) already had the correct setting. "
        "The sibling dependency declaration enables the API's dependency resolution to know "
        "that 3.5.1.1 is needed."
    )

    # --- 3.11 ---
    doc.add_heading("3.11 Answer utilities: sibling dependency injection", level=3)
    doc.add_paragraph("File: cdp3_1-main/backend/api/answer_utils.py")
    doc.add_paragraph(
        "New function get_sibling_dependencies(scoring_group): dynamically imports the schema "
        "module, reads GROUP_DEPENDENCIES, returns field dependencies whose source_group is NOT "
        "a parent of the scoring group (i.e., sibling dependencies).\n\n"
        "Modified function prepare_answers_for_scoring(): after parent dependency extraction, "
        "calls get_sibling_dependencies() and ensures all sibling dependency answers present in "
        "the payload are preserved in the enhanced answers dict."
    )
    doc.add_paragraph(
        "Why: The original function only traversed parent groups (3.5 -> 3). It did not handle "
        "sibling groups (3.5.1). Without this, 3.5.1.1 could be dropped from the answers even "
        "when the caller included it."
    )

    # --- 3.12 ---
    doc.add_heading("3.12 API documentation", level=3)
    doc.add_paragraph("File: cdp3_1-main/backend/api/test_requests/TESTING_GUIDE.md")
    doc.add_paragraph(
        'Added section "Scoring Groups with Sibling Dependencies (row_source)" with:'
    )
    doc.add_paragraph("Two minimal curl examples (group route + /score endpoint with dependency_answers)", style="List Bullet")
    doc.add_paragraph("Behavior table showing when penalty is triggered", style="List Bullet")
    doc.add_paragraph("Explicit statement that the API is stateless and does not auto-fetch sibling answers", style="List Bullet")

    # --- 3.13 ---
    doc.add_heading("3.13 Tests (13 total)", level=3)
    doc.add_paragraph("File: cdp3_1-main/backend/tests/questions/test_scoring_3_5_2.py (8 tests)")
    tests_352 = [
        "test_row_source_dep_question_constant — verifies ROW_SOURCE_DEP_QUESTION == '3.5.1.1'",
        "test_schema_extra_allow — verifies model_config extra == 'allow'",
        "test_schema_declares_row_source_dependency — verifies GROUP_DEPENDENCIES has row_source entry for 3.5.1.1",
        "test_scoring_with_row_source_penalty — 2 ETS expected, 1 submitted -> disclosure < max",
        "test_scoring_without_row_source_no_penalty — no 3.5.1.1 in payload -> no penalty applied",
        "test_scoring_full_rows_no_penalty — 1 expected, 1 submitted -> same score as without row_source",
        "test_answer_utils_injects_sibling_dependency — prepare_answers_for_scoring retains 3.5.1.1",
        "test_group_route_requires_sibling_dependency_in_same_payload — documents and enforces stateless design",
    ]
    for t in tests_352:
        doc.add_paragraph(t, style="List Bullet")
    doc.add_paragraph("\nFile: cdp3_1-main/backend/tests/questions/test_scoring_3_5_3.py (5 tests)")
    tests_353 = [
        "test_row_source_dep_question_constant — verifies ROW_SOURCE_DEP_QUESTION == '3.5.1.1'",
        "test_schema_extra_allow — verifies model_config extra == 'allow'",
        "test_schema_declares_row_source_dependency — verifies GROUP_DEPENDENCIES has row_source entry for 3.5.1.1",
        "test_scoring_with_row_source_penalty — 2 tax systems expected, 1 submitted -> disclosure penalized",
        "test_scoring_without_row_source_no_penalty — no 3.5.1.1 in payload -> no penalty applied",
    ]
    for t in tests_353:
        doc.add_paragraph(t, style="List Bullet")

    # =========================================================================
    doc.add_heading("4. Generated Files (Final State)", level=2)
    doc.add_paragraph("Files: cdp3_1-main/backend/scoring/scoring_group_3_5_2.py, scoring_group_3_5_3.py")
    doc.add_paragraph(
        "These are auto-generated by the compiler and reflect all changes above. Key sections:"
    )
    add_table(
        doc,
        ["Content", "Purpose", "From Change"],
        [
            ["ROW_SOURCE_DEP_QUESTION = '3.5.1.1'", "Sibling dependency discoverability", "3.8"],
            ["return (zero_scores, defaultdict(list))", "Safe empty-row handling", "3.5"],
            ["_unconditional_questions: all sub-questions", "No broken conditional_on filtering", "3.2"],
            ["_rs_answer / _rs_expected / _rs_actual_ratio / zero-padding", "Missing-row disclosure penalty", "3.6"],
            ["group_X = group_X * _rs_actual_ratio", "Category scaling for missing rows", "3.7"],
        ],
    )
    doc.add_paragraph("scoring_group_3_5_3.py has identical structure; keyword filter uses 'tax' instead of 'ets'.")

    # =========================================================================
    doc.add_heading("5. Behavior Comparison (Original vs Final)", level=2)
    add_table(
        doc,
        ["Scenario", "Disclosure: Original", "Disclosure: Final", "Awareness: Original", "Awareness: Final"],
        [
            ["3 expected, 3 submitted", "avg(r1,r2,r3)", "avg(r1,r2,r3)", "full", "full"],
            ["3 expected, 1 submitted", "avg(r1) — no penalty", "avg(r1,0,0) = 1/3", "full if row complete", "1/3 x computed"],
            ["1 expected, 0 submitted", "TypeError (returned {})", "0.0 (zero tuple)", "TypeError", "0.0"],
            ["1 expected, 2 submitted", "avg(r1,r2)", "avg(r1,r2)", "no cap, can inflate", "capped at 1x max"],
            ["Sub-q with conditional_on", "visible_count=1 (only grouping q)", "All 10/5 sub-questions visible", "inflated from 1 q", "correct from all"],
        ],
    )

    # =========================================================================
    doc.add_heading("6. Design Decision: Stateless Sibling Dependency", level=2)
    doc.add_paragraph(
        "Group-specific score routes (e.g., /score/3.5.2) do not automatically fetch sibling "
        "dependency answers from persistence. This is by design for a stateless API."
    )
    doc.add_paragraph("Callers provide sibling answers via one of two methods:")
    doc.add_paragraph("Group route: include '3.5.1.1' directly in the answers dict", style="List Bullet")
    doc.add_paragraph(
        'Schema-validated /score endpoint: pass dependency_answers with '
        '[{"group_id": "3.5.1", "3.5.1.1": [...]}]',
        style="List Bullet",
    )
    doc.add_paragraph(
        "Hard enforcement (HTTP 422 when 3.5.1.1 is absent) was evaluated and rejected: not all "
        "companies have carbon pricing exposure, so 3.5.1.1 may legitimately be absent. The "
        "ROW_SOURCE_DEP_QUESTION constant provides discoverability without hard constraints."
    )
    doc.add_paragraph(
        "This behavior is documented in TESTING_GUIDE.md and locked by test "
        "test_group_route_requires_sibling_dependency_in_same_payload."
    )

    # =========================================================================
    doc.add_heading("7. Test Results", level=2)
    doc.add_paragraph("13 new tests: all passed (pytest, Python 3.11.13)")
    doc.add_paragraph("231 existing tests: all passed (no regressions)")
    doc.add_paragraph(
        "Pre-existing failures unrelated to this work: 1 test (missing google.generativeai "
        "module) and 1 collection error (missing fastapi module)."
    )

    # =========================================================================
    doc.add_heading("8. Conclusion", level=2)
    doc.add_paragraph(
        "The row_source fixed-row scoring mechanism for CDP groups 3.5.2 and 3.5.3 is now "
        "fully implemented end-to-end. Starting from a codebase with no support for "
        "parent-question-driven row expectations, the changes span:"
    )
    bullets = [
        "Spreadsheet metadata: row_source column and corrected question_type/conditional_on",
        "Compiler pipeline: QuestionSpec, parser, row-based detection, penalty generation, category scaling, constant generation, schema generator",
        "Generated scoring functions: auto-regenerated with all new logic",
        "API layer: schema acceptance (extra: allow), sibling dependency declaration (GROUP_DEPENDENCIES), answer preparation (sibling injection)",
        "Documentation: TESTING_GUIDE.md with request examples and behavior table",
        "Tests: 13 regression tests covering schema, dependency, scoring, and stateless design",
    ]
    for b in bullets:
        doc.add_paragraph(b, style="List Bullet")

    doc.save(path)
    print(f"EN saved: {path}")


# =============================================================================
# CHINESE
# =============================================================================
def build_cn(path):
    doc = Document()
    style = doc.styles["Normal"]
    style.font.name = "Calibri"
    style.font.size = Pt(10)

    doc.add_heading(
        "统一变更报告\n"
        "CDP 3.5.2 / 3.5.3 固定行评分 — 完整实现",
        level=1,
    )

    p = doc.add_paragraph()
    p.add_run("日期：").bold = True
    p.add_run("2026-03-08\n")
    p.add_run("范围：").bold = True
    p.add_run("评分组 3.5.2（排放交易系统 ETS）和 3.5.3（碳税）\n")
    p.add_run("目标：").bold = True
    p.add_run(
        "实现「由父题选项驱动的固定行」机制 — 3.5.2/3.5.3 的预期行数由父题 3.5.1.1 的答案决定；"
        "未提交的预期行按零分处理。实现覆盖完整技术栈：电子表格元数据、编译器流水线、评分函数、"
        "API Schema、依赖传播、答案工具、测试和文档。"
    )

    # =========================================================================
    doc.add_heading("1. 问题描述", level=2)
    doc.add_paragraph(
        "CDP 问卷组 3.5.2（ETS 详情）和 3.5.3（碳税详情）是多行表格。每行对应受访者在题目 "
        "3.5.1.1 中选择的一个碳定价系统。原始代码库缺乏以下能力："
    )
    bullets = [
        "识别 3.5.2/3.5.3 为行结构组（电子表格元数据缺失）",
        "根据 3.5.1.1 的选项确定预期行数",
        "对缺失行进行 disclosure 扣分",
        "按比例缩放 awareness/management/leadership 分数",
        "通过 API Schema 层接受行前缀答案键",
        "传播同级依赖（3.5.1.1）使评分函数能接收到它",
    ]
    for b in bullets:
        doc.add_paragraph(b, style="List Bullet")
    doc.add_paragraph(
        "因此，企业在 3.5.1.1 中选择了 3 个 ETS 系统但仅提交 1 行 3.5.2 数据时，得分与提交全部 "
        "3 行完全相同。此外，condition_parser 的一个 bug 导致 3.5.2/3.5.3 的所有子题被判定为不可见，"
        "仅回答分组题即可获满分。"
    )

    # =========================================================================
    doc.add_heading("2. 全部修改和新增文件", level=2)
    add_table(
        doc,
        ["#", "文件", "类型", "变更内容"],
        [
            ["1", "cdp3_1-main/CDP_scoring_questions.xlsx", "修改",
             "新增 row_source 列；修改 question_type 为 multi-row；清空 15 个错误的 conditional_on 值"],
            ["2", "cdp3_1-main/backend/compiler/compiler_config.py", "修改",
             "在 QuestionSpec 数据类中新增 row_source 字段"],
            ["3", "cdp3_1-main/backend/compiler/spreadsheet_parser.py", "修改",
             "新增 row_source 读取；is_row_based_scoring_group() 新增 row_source 检测"],
            ["4", "cdp3_1-main/backend/compiler/scoring_rules/generators/multi_row/main.py", "修改",
             "修复空行返回类型；新增 _build_row_source_penalty()；新增 _build_row_source_category_scaling()"],
            ["5", "cdp3_1-main/backend/compiler/scoring_rules/template_builder.py", "修改",
             "新增 ROW_SOURCE_DEP_QUESTION 常量生成"],
            ["6", "cdp3_1-main/backend/compiler/schema_generator.py", "修改",
             "is_multi_row 检测增加 row_source；依赖生成增加 row_source 同级依赖"],
            ["7", "cdp3_1-main/backend/scoring/scoring_group_3_5_2.py", "重新生成",
             "由编译器自动重新生成；反映上述所有编译器改动"],
            ["8", "cdp3_1-main/backend/scoring/scoring_group_3_5_3.py", "重新生成",
             "由编译器自动重新生成；反映上述所有编译器改动"],
            ["9", "cdp3_1-main/backend/api/schemas/groups/group_3_5_2.py", "修改",
             'extra: "forbid" → "allow"；GROUP_DEPENDENCIES 添加 3.5.1.1 同级依赖'],
            ["10", "cdp3_1-main/backend/api/schemas/groups/group_3_5_3.py", "修改",
             "同 group_3_5_2.py"],
            ["11", "cdp3_1-main/backend/api/answer_utils.py", "修改",
             "新增 get_sibling_dependencies()；prepare_answers_for_scoring() 注入同级依赖"],
            ["12", "cdp3_1-main/backend/api/test_requests/TESTING_GUIDE.md", "修改",
             "新增 row_source 同级依赖章节及请求示例"],
            ["13", "cdp3_1-main/backend/tests/questions/test_scoring_3_5_2.py", "新建",
             "8 个测试：Schema、依赖、评分罚分、answer_utils、无状态行为"],
            ["14", "cdp3_1-main/backend/tests/questions/test_scoring_3_5_3.py", "新建",
             "5 个测试：Schema、依赖、评分罚分"],
        ],
    )

    # =========================================================================
    doc.add_heading("3. 变更详情", level=2)

    # --- 3.1 ---
    doc.add_heading("3.1 电子表格：row_source 元数据与 question_type", level=3)
    doc.add_paragraph("文件：cdp3_1-main/CDP_scoring_questions.xlsx")
    add_table(
        doc,
        ["题目", "列名", "原始", "修改后"],
        [
            ["3.5.2.0", "question_type", "classification", "multi-row"],
            ["3.5.2.0", "classification_options", "（空）",
             '{"type":"multi-row","options":[],"question_type":"multi-row"}'],
            ["3.5.2.0", "row_source", "（该列不存在）", "3.5.1.1:contains=ETS"],
            ["3.5.3.0", "question_type", "classification", "multi-row"],
            ["3.5.3.0", "classification_options", "（空）",
             '{"type":"multi-row","options":[],"question_type":"multi-row"}'],
            ["3.5.3.0", "row_source", "（该列不存在）", "3.5.1.1:contains=tax"],
        ],
    )
    doc.add_paragraph(
        "原因：编译器仅当 question_type='multi-row' 时才将评分组路由至 FixedRowsMainGenerator。"
        "row_source 字段编码了由哪道父题和关键词过滤器确定预期行数。缺少这些设置，编译器会产生"
        "平铺（非行结构）评分逻辑，不进行行迭代。"
    )

    # --- 3.2 ---
    doc.add_heading("3.2 电子表格：清空 15 个错误的 conditional_on", level=3)
    doc.add_paragraph("文件：cdp3_1-main/CDP_scoring_questions.xlsx")
    doc.add_paragraph(
        "题目 3.5.2.1-3.5.2.10（10 行）：conditional_on 为 '3.5.0.1 != NULL' → 清空。\n"
        "题目 3.5.3.1-3.5.3.5（5 行）：各类 conditional_on 值 → 清空。"
    )
    doc.add_paragraph(
        "原因：condition_parser.py 存在结构性缺陷。当 conditional_on 引用平铺组题目时（3.5.0.1 在组 3.5 中），"
        "解析器生成："
    )
    add_code_block(doc, "any(_key.startswith('3.5.Row') for _key in answers)")
    doc.add_paragraph(
        "但 3.5.2 中实际键格式为 '3.5.2.Row N.3.5.2.Y'——前缀 '3.5.Row' 永远不匹配。"
        "全部 10 道子题被判定为不可见，仅分组题 3.5.2.0 被计分，回答系统名称即获满分。"
        "对固定行组而言，行内子题只要行存在即无条件可见。清空条件彻底消除错误逻辑。"
    )

    # --- 3.3 ---
    doc.add_heading("3.3 编译器：QuestionSpec.row_source 字段", level=3)
    doc.add_paragraph("文件：cdp3_1-main/backend/compiler/compiler_config.py")
    doc.add_paragraph("新增：")
    add_code_block(doc,
        "# Row source: specifies which parent question's answers determine the rows\n"
        "# Format: \"parent_question_num\" or \"parent_question_num:contains=keyword\"\n"
        "row_source: Optional[str] = None"
    )
    doc.add_paragraph(
        "原因：若无此字段，从 Excel 读取的 row_source 值无处存储，会在到达生成器前被静默丢弃。"
    )

    # --- 3.4 ---
    doc.add_heading("3.4 编译器：电子表格解析器 — row_source 读取与检测", level=3)
    doc.add_paragraph("文件：cdp3_1-main/backend/compiler/spreadsheet_parser.py")
    doc.add_paragraph(
        "A）在 _parse_row() 中新增 row_source=get_value('row_source')，从 Excel 列读取到 QuestionSpec。\n\n"
        "B）在 is_row_based_scoring_group() 中，于现有 question_type 检查和 conditional_on 模式检查之间"
        "新增 row_source 检查："
    )
    add_code_block(doc,
        "# 检查是否含有 row_source（固定行由父题驱动）\n"
        "if first_question.row_source:\n"
        "    return True"
    )
    doc.add_paragraph(
        "原因：(A) 不读取该列则 row_source 始终为 None。"
        "(B) 此函数决定编译器是否路由至行结构生成器。含 row_source 的组可能缺少原有检测所依赖的 "
        "conditional_on 模式。"
    )

    # --- 3.5 ---
    doc.add_heading("3.5 编译器：空行返回类型修复", level=3)
    doc.add_paragraph("文件：cdp3_1-main/backend/compiler/scoring_rules/generators/multi_row/main.py")
    doc.add_paragraph("原始生成代码：")
    add_code_block(doc, "if not rows:\n    return {}")
    doc.add_paragraph("修改后生成代码：")
    add_code_block(doc,
        "if not rows:\n"
        "    from collections import defaultdict\n"
        "    return ({'disclosure': 0.0, 'awareness': 0.0, 'management': 0.0,\n"
        "             'leadership': 0.0}, defaultdict(list))"
    )
    doc.add_paragraph(
        "原因：所有评分函数必须返回 (scores_dict, tracking_dict) 元组。返回裸 {} 会在 API 层解包时"
        "引发 TypeError。"
    )

    # --- 3.6 ---
    doc.add_heading("3.6 编译器：缺失行罚分机制", level=3)
    doc.add_paragraph("文件：cdp3_1-main/backend/compiler/scoring_rules/generators/multi_row/main.py")
    doc.add_paragraph("新增方法 _build_row_source_penalty() 生成的运行时代码：")
    bullets = [
        "读取父题答案（如 answers.get('3.5.1.1')）",
        "按关键词过滤（如 'ets' 或 'tax'）得到预期行列表",
        "计算 _rs_missing = max(0, 预期行数 - 已提交行数)",
        "为每个缺失行向 group_disclosure_scores 追加 0.0",
        "计算 _rs_actual_ratio = min(1.0, 已提交/预期)，封顶 1.0",
        "为每个缺失行添加 tracking 条目，reason 为 'Row expected from parent question but not submitted'",
    ]
    for b in bullets:
        doc.add_paragraph(b, style="List Bullet")
    doc.add_paragraph(
        "原因：原始代码中 avg_disclosure 以 len(已提交行) 为分母而非 len(预期行)。企业提交 3 行中的 "
        "1 行与提交全部 3 行得分完全相同。"
    )

    # --- 3.7 ---
    doc.add_heading("3.7 编译器：缺失行的 category 缩放", level=3)
    doc.add_paragraph("文件：cdp3_1-main/backend/compiler/scoring_rules/generators/multi_row/main.py")
    doc.add_paragraph("新增方法 _build_row_source_category_scaling() 生成：")
    add_code_block(doc,
        "group_awareness = group_awareness * _rs_actual_ratio\n"
        "group_management = group_management * _rs_actual_ratio\n"
        "group_leadership = group_leadership * _rs_actual_ratio"
    )
    doc.add_paragraph(
        "原因：原始代码中 awareness/management/leadership 基于所有已提交行合并评分，不因缺失行调整。"
        "若预期 3 行仅提交 1 行：disclosure 正确扣至 1/3，但 awareness 获满分——不一致。"
        "乘以 _rs_actual_ratio（封顶 1.0）确保四个维度受到一致的比例惩罚。"
    )

    # --- 3.8 ---
    doc.add_heading("3.8 编译器：ROW_SOURCE_DEP_QUESTION 常量", level=3)
    doc.add_paragraph("文件：cdp3_1-main/backend/compiler/scoring_rules/template_builder.py")
    doc.add_paragraph(
        "build_scoring_file() 中新增代码，扫描题目的 row_source 并在评分文件中生成模块级常量："
    )
    add_code_block(doc,
        "# Sibling question required for row_source penalty scoring.\n"
        "# Include this question's answer in the API payload when scoring 3.5.2.\n"
        "ROW_SOURCE_DEP_QUESTION = '3.5.1.1'"
    )
    doc.add_paragraph(
        "原因：评分函数运行时通过 answers.get('3.5.1.1') 读取父题答案。若调用方未传入，罚分逻辑被"
        "静默跳过。此常量为 API 消费者提供可发现性，并支持未来自动回填逻辑。硬性 API 验证（缺少 "
        "3.5.1.1 时返回 HTTP 422）经评估后被否决：并非所有企业都有碳定价敞口，3.5.1.1 合法地可能为空。"
    )

    # --- 3.9 ---
    doc.add_heading("3.9 Schema 生成器：is_multi_row 与依赖生成", level=3)
    doc.add_paragraph("文件：cdp3_1-main/backend/compiler/schema_generator.py")
    doc.add_paragraph("A）is_multi_row 检测 — 原始：")
    add_code_block(doc,
        'is_multi_row = any(\n'
        '    q.question_type and "multi-row" in q.question_type.lower()\n'
        '    for q in questions\n'
        ')'
    )
    doc.add_paragraph("修改后：")
    add_code_block(doc,
        'is_multi_row = any(\n'
        '    (q.question_type and "multi-row" in q.question_type.lower())\n'
        '    or getattr(q, \'row_source\', None)\n'
        '    for q in questions\n'
        ')'
    )
    doc.add_paragraph(
        "B）依赖生成：在现有字段依赖循环后，新增代码检查每个问题的 row_source。若存在，提取父级"
        "问题编号和来源组，追加 reason=\"row_source\" 的字段依赖到 GROUP_DEPENDENCIES。"
    )
    doc.add_paragraph(
        "原因：(A) 使用 row_source 的组未被检测为多行，导致 Schema 中输出 extra: \"forbid\"——"
        "拒绝行前缀 payload 键。(B) 不加此项，重新编译会丢失同级依赖声明。"
    )

    # --- 3.10 ---
    doc.add_heading("3.10 API Schema：extra 策略与同级依赖", level=3)
    doc.add_paragraph("文件：cdp3_1-main/backend/api/schemas/groups/group_3_5_2.py、group_3_5_3.py")
    add_table(
        doc,
        ["属性", "原始", "修改后"],
        [
            ['model_config["extra"]', '"forbid"', '"allow"'],
            ["GROUP_DEPENDENCIES.fields", "仅 3.5.0.1（conditional_on）",
             "3.5.0.1（conditional_on）+ 3.5.1.1（row_source，source_group: 3.5.1）"],
        ],
    )
    doc.add_paragraph(
        "原因：\"forbid\" 拒绝 \"3.5.2.Row 1.3.5.2.1\" 等行前缀键，导致 Schema 验证的 /score 端点"
        "无法用于多行提交。group_7_30_16.py（另一个多行组）已有正确设置。"
        "同级依赖声明使 API 的依赖解析逻辑知道需要 3.5.1.1。"
    )

    # --- 3.11 ---
    doc.add_heading("3.11 答案工具：同级依赖注入", level=3)
    doc.add_paragraph("文件：cdp3_1-main/backend/api/answer_utils.py")
    doc.add_paragraph(
        "新增函数 get_sibling_dependencies(scoring_group)：动态导入 Schema 模块，读取 "
        "GROUP_DEPENDENCIES，返回 source_group 不属于该评分组父级的字段依赖（即同级依赖）。\n\n"
        "修改函数 prepare_answers_for_scoring()：在父级依赖提取后，调用 get_sibling_dependencies()，"
        "确保 payload 中的同级依赖答案被保留在增强后的答案字典中。"
    )
    doc.add_paragraph(
        "原因：原始函数仅遍历父级组（3.5 → 3），不处理同级组（3.5.1）。不加此改动，即使调用方"
        "传入了 3.5.1.1 也可能被丢弃。"
    )

    # --- 3.12 ---
    doc.add_heading("3.12 API 文档", level=3)
    doc.add_paragraph("文件：cdp3_1-main/backend/api/test_requests/TESTING_GUIDE.md")
    doc.add_paragraph("新增 \"Scoring Groups with Sibling Dependencies (row_source)\" 章节，包含：")
    doc.add_paragraph("两个最小 curl 请求示例（组路由 + /score 端点 + dependency_answers）", style="List Bullet")
    doc.add_paragraph("行为表格，展示罚分触发条件", style="List Bullet")
    doc.add_paragraph("明确说明 API 为无状态设计，不自动获取同级答案", style="List Bullet")

    # --- 3.13 ---
    doc.add_heading("3.13 测试（共 13 个）", level=3)
    doc.add_paragraph("文件：cdp3_1-main/backend/tests/questions/test_scoring_3_5_2.py（8 个测试）")
    tests_352 = [
        "test_row_source_dep_question_constant — 验证 ROW_SOURCE_DEP_QUESTION == '3.5.1.1'",
        "test_schema_extra_allow — 验证 model_config extra == 'allow'",
        "test_schema_declares_row_source_dependency — 验证 GROUP_DEPENDENCIES 含 3.5.1.1 的 row_source 条目",
        "test_scoring_with_row_source_penalty — 期望 2 个 ETS、提交 1 行 → disclosure < max",
        "test_scoring_without_row_source_no_penalty — payload 中无 3.5.1.1 → 不罚分",
        "test_scoring_full_rows_no_penalty — 期望 1 行、提交 1 行 → 与无 row_source 等同",
        "test_answer_utils_injects_sibling_dependency — prepare_answers_for_scoring 保留 3.5.1.1",
        "test_group_route_requires_sibling_dependency_in_same_payload — 记录并固定无状态设计",
    ]
    for t in tests_352:
        doc.add_paragraph(t, style="List Bullet")
    doc.add_paragraph("\n文件：cdp3_1-main/backend/tests/questions/test_scoring_3_5_3.py（5 个测试）")
    tests_353 = [
        "test_row_source_dep_question_constant — 验证 ROW_SOURCE_DEP_QUESTION == '3.5.1.1'",
        "test_schema_extra_allow — 验证 model_config extra == 'allow'",
        "test_schema_declares_row_source_dependency — 验证 GROUP_DEPENDENCIES 含 3.5.1.1 的 row_source 条目",
        "test_scoring_with_row_source_penalty — 期望 2 个 tax 系统、提交 1 行 → disclosure 受罚",
        "test_scoring_without_row_source_no_penalty — payload 中无 3.5.1.1 → 不罚分",
    ]
    for t in tests_353:
        doc.add_paragraph(t, style="List Bullet")

    # =========================================================================
    doc.add_heading("4. 生成文件（最终状态）", level=2)
    doc.add_paragraph("文件：cdp3_1-main/backend/scoring/scoring_group_3_5_2.py、scoring_group_3_5_3.py")
    doc.add_paragraph("这些文件由编译器自动生成，反映上述所有改动。关键段落：")
    add_table(
        doc,
        ["内容", "用途", "来自改动"],
        [
            ["ROW_SOURCE_DEP_QUESTION = '3.5.1.1'", "同级依赖可发现性", "3.8"],
            ["return (零分字典, defaultdict(list))", "安全的空行处理", "3.5"],
            ["_unconditional_questions: 包含全部子题", "无错误的 conditional_on 过滤", "3.2"],
            ["_rs_answer / _rs_expected / _rs_actual_ratio / 补零", "缺失行 disclosure 罚分", "3.6"],
            ["group_X = group_X * _rs_actual_ratio", "缺失行的 category 缩放", "3.7"],
        ],
    )
    doc.add_paragraph("scoring_group_3_5_3.py 结构相同；关键词过滤使用 'tax' 而非 'ets'。")

    # =========================================================================
    doc.add_heading("5. 行为对比（原始 vs 最终）", level=2)
    add_table(
        doc,
        ["场景", "Disclosure：原始", "Disclosure：最终", "Awareness：原始", "Awareness：最终"],
        [
            ["期望 3 行，提交 3 行", "avg(r1,r2,r3)", "avg(r1,r2,r3)", "满分", "满分"],
            ["期望 3 行，提交 1 行", "avg(r1)，无罚分", "avg(r1,0,0) = 1/3", "该行完整则满分", "1/3 × 计算值"],
            ["期望 1 行，提交 0 行", "TypeError（返回 {}）", "0.0（零分元组）", "TypeError", "0.0"],
            ["期望 1 行，提交 2 行", "avg(r1,r2)", "avg(r1,r2)", "无上限，可虚高", "封顶于 1× 上限"],
            ["子题有 conditional_on", "visible_count=1（仅分组题）", "全部 10/5 道子题可见", "仅 1 题计分，虚高", "基于全部题目，正确"],
        ],
    )

    # =========================================================================
    doc.add_heading("6. 设计决策：无状态同级依赖", level=2)
    doc.add_paragraph(
        "组级评分路由（如 /score/3.5.2）不会自动从持久层获取同级依赖答案。这是无状态 API 的设计选择。"
    )
    doc.add_paragraph("调用方通过以下两种方式之一提供同级答案：")
    doc.add_paragraph("组路由：在 answers 字典中直接包含 '3.5.1.1'", style="List Bullet")
    doc.add_paragraph(
        "Schema 验证的 /score 端点：通过 dependency_answers 传入 "
        '[{"group_id": "3.5.1", "3.5.1.1": [...]}]',
        style="List Bullet",
    )
    doc.add_paragraph(
        "硬性验证方案（缺少 3.5.1.1 时返回 HTTP 422）经评估后被否决：并非所有企业都有碳定价敞口，"
        "3.5.1.1 合法地可能为空。ROW_SOURCE_DEP_QUESTION 常量提供可发现性，无需硬性约束。"
    )
    doc.add_paragraph(
        "此行为已在 TESTING_GUIDE.md 中记录，并由测试 "
        "test_group_route_requires_sibling_dependency_in_same_payload 固定。"
    )

    # =========================================================================
    doc.add_heading("7. 测试结果", level=2)
    doc.add_paragraph("13 个新测试：全部通过（pytest，Python 3.11.13）")
    doc.add_paragraph("231 个已有测试：全部通过（无回归）")
    doc.add_paragraph(
        "预先存在的与本次变更无关的问题：1 个测试失败（缺少 google.generativeai 模块）和 "
        "1 个收集错误（缺少 fastapi 模块）。"
    )

    # =========================================================================
    doc.add_heading("8. 结论", level=2)
    doc.add_paragraph(
        "CDP 组 3.5.2 和 3.5.3 的 row_source 固定行评分机制现已端到端完整实现。"
        "从一个完全不支持父题驱动行预期的代码库出发，变更覆盖："
    )
    bullets = [
        "电子表格元数据：row_source 列及修正的 question_type/conditional_on",
        "编译器流水线：QuestionSpec、解析器、行结构检测、罚分生成、category 缩放、常量生成、Schema 生成器",
        "生成的评分函数：自动重新生成，包含全部新逻辑",
        "API 层：Schema 接纳（extra: allow）、同级依赖声明（GROUP_DEPENDENCIES）、答案准备（同级注入）",
        "文档：TESTING_GUIDE.md 中的请求示例和行为表格",
        "测试：13 个回归测试，覆盖 Schema、依赖、评分和无状态设计",
    ]
    for b in bullets:
        doc.add_paragraph(b, style="List Bullet")

    doc.save(path)
    print(f"CN saved: {path}")


if __name__ == "__main__":
    build_en(os.path.join(OUTPUT_DIR, "change_report_unified_EN.docx"))
    build_cn(os.path.join(OUTPUT_DIR, "change_report_unified_CN.docx"))
