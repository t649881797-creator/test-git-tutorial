"""
Build Phase 2 change report in Word format (English + Chinese).
Run: python AIESG/cdp3_1/report/build_phase2_report.py
"""

from docx import Document
from docx.shared import Pt, Inches, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT
import os

OUTPUT_DIR = os.path.dirname(os.path.abspath(__file__))


def set_cell_text(cell, text, bold=False, size=9):
    cell.text = ""
    p = cell.paragraphs[0]
    run = p.add_run(text)
    run.font.size = Pt(size)
    run.font.name = "Calibri"
    if bold:
        run.bold = True


def add_table(doc, headers, rows):
    table = doc.add_table(rows=1 + len(rows), cols=len(headers))
    table.style = "Table Grid"
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    # Header
    for i, h in enumerate(headers):
        set_cell_text(table.rows[0].cells[i], h, bold=True)
        table.rows[0].cells[i].paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER
    # Data
    for r_idx, row in enumerate(rows):
        for c_idx, val in enumerate(row):
            set_cell_text(table.rows[r_idx + 1].cells[c_idx], str(val))
    return table


def build_en(path):
    doc = Document()
    style = doc.styles["Normal"]
    style.font.name = "Calibri"
    style.font.size = Pt(10)

    doc.add_heading(
        "Change Report (Phase 2) — Schema, Dependency Propagation & API Consistency Fix\n"
        "for CDP 3.5.2 / 3.5.3 row_source Groups",
        level=1,
    )

    p = doc.add_paragraph()
    p.add_run("Date: ").bold = True
    p.add_run("2026-03-08\n")
    p.add_run("Scope: ").bold = True
    p.add_run("Scoring groups 3.5.2 (ETS) and 3.5.3 (Carbon Tax) — schema acceptance, "
              "sibling dependency propagation, answer preparation utility, tests, and documentation\n")
    p.add_run("Relation to Phase 1: ").bold = True
    p.add_run("Phase 1 (change_report_EN.md) implemented the core row_source scoring logic in the compiler "
              "and generated scoring functions. Phase 2 closes the remaining gaps at the API/schema/test layer.")

    # --- Section 1 ---
    doc.add_heading("1. Summary of Issues Addressed", level=2)
    doc.add_paragraph(
        "Phase 1 delivered the scoring-engine changes (compiler, generator, scoring functions). "
        "However, three gaps remained that prevented the API from being fully usable by external callers:",
        style="List Bullet",
    )
    doc.add_paragraph(
        "Issue A — Schema rejection: group_3_5_2.py and group_3_5_3.py used extra: \"forbid\" in their "
        "Pydantic model_config. This rejected row-prefixed keys like \"3.5.2.Row 1.3.5.2.1\", making it "
        "impossible to submit multi-row payloads through the schema-validated /score endpoint. "
        "group_7_30_16.py (another multi-row group) already had the correct setting: extra: \"allow\".",
        style="List Bullet",
    )
    doc.add_paragraph(
        "Issue B — Missing sibling dependency declaration: GROUP_DEPENDENCIES in the schema files for 3.5.2 "
        "and 3.5.3 only declared the parent dependency (3.5.0.1 from group 3.5). The row_source sibling "
        "dependency (3.5.1.1 from group 3.5.1) was not declared, so the API's dependency resolution logic "
        "had no way to know it was needed.",
        style="List Bullet",
    )
    doc.add_paragraph(
        "Issue C — answer_utils only handled parent dependencies: prepare_answers_for_scoring() traversed "
        "parent groups (e.g., 3.5 -> 3) but not sibling groups (3.5.1). Even if 3.5.1.1 was included in "
        "the same request payload, the function would not specifically preserve it as a dependency.",
        style="List Bullet",
    )

    # --- Section 2 ---
    doc.add_heading("2. Modified Files", level=2)
    add_table(
        doc,
        ["File", "Type", "Nature of Change"],
        [
            ["backend/compiler/schema_generator.py", "Modified",
             "is_multi_row detection now includes row_source; dependency generation adds row_source sibling deps"],
            ["backend/api/schemas/groups/group_3_5_2.py", "Modified",
             "extra: \"forbid\" -> \"allow\"; GROUP_DEPENDENCIES adds 3.5.1.1 (reason: row_source)"],
            ["backend/api/schemas/groups/group_3_5_3.py", "Modified",
             "Same as group_3_5_2.py"],
            ["backend/api/answer_utils.py", "Modified",
             "New get_sibling_dependencies(); prepare_answers_for_scoring() injects sibling deps"],
            ["backend/api/test_requests/TESTING_GUIDE.md", "Modified",
             "Added section on row_source sibling dependency with minimal request examples"],
            ["backend/tests/questions/test_scoring_3_5_2.py", "New",
             "8 tests covering schema, dependency, scoring penalty, answer_utils, stateless behavior"],
            ["backend/tests/questions/test_scoring_3_5_3.py", "New",
             "5 tests covering schema, dependency, scoring penalty"],
        ],
    )

    # --- Section 3 ---
    doc.add_heading("3. Change Details", level=2)

    doc.add_heading("3.1 Schema Generator — Root Cause Fix", level=3)
    doc.add_paragraph("File: backend/compiler/schema_generator.py")
    doc.add_heading("3.1a is_multi_row detection", level=4)
    doc.add_paragraph("Original:")
    doc.add_paragraph(
        'is_multi_row = any(\n'
        '    q.question_type and "multi-row" in q.question_type.lower()\n'
        '    for q in questions\n'
        ')',
        style="No Spacing",
    )
    doc.add_paragraph("Final:")
    doc.add_paragraph(
        'is_multi_row = any(\n'
        '    (q.question_type and "multi-row" in q.question_type.lower())\n'
        '    or getattr(q, \'row_source\', None)\n'
        '    for q in questions\n'
        ')',
        style="No Spacing",
    )
    doc.add_paragraph(
        "Why: Groups 3.5.2 and 3.5.3 use row_source (not question_type=\"multi-row\") to define their "
        "multi-row structure. Without this fix, the generator treats them as flat groups and emits "
        "extra: \"forbid\" in the schema."
    )

    doc.add_heading("3.1b Dependency generation for row_source", level=4)
    doc.add_paragraph(
        "Added code after the existing field dependency loop that inspects each question's row_source attribute. "
        "If row_source is set, extracts the parent question number (e.g., \"3.5.1.1\" from \"3.5.1.1:contains=ETS\") "
        "and its source group (\"3.5.1\"), then appends a field dependency entry with reason=\"row_source\" to "
        "GROUP_DEPENDENCIES. Duplicates are checked against existing entries."
    )
    doc.add_paragraph(
        "Why: Without this, recompiling would regenerate schema files without the sibling dependency, "
        "losing the manual fix."
    )

    doc.add_heading("3.2 Schema Files — Generated Output Fix", level=3)
    doc.add_paragraph("Files: group_3_5_2.py, group_3_5_3.py")
    add_table(
        doc,
        ["Attribute", "Original", "Final"],
        [
            ["model_config[\"extra\"]", "\"forbid\"", "\"allow\""],
            ["GROUP_DEPENDENCIES.fields", "Only 3.5.0.1 (conditional_on)",
             "3.5.0.1 (conditional_on) + 3.5.1.1 (row_source)"],
        ],
    )
    doc.add_paragraph(
        "These files are auto-generated. The manual fix is applied now; future recompiles will produce "
        "the correct output thanks to the generator fix in 3.1."
    )

    doc.add_heading("3.3 answer_utils.py — Sibling Dependency Injection", level=3)
    doc.add_paragraph("File: backend/api/answer_utils.py")
    doc.add_heading("New function: get_sibling_dependencies()", level=4)
    doc.add_paragraph(
        "Dynamically imports the schema module for the given scoring group, reads GROUP_DEPENDENCIES, "
        "and returns any field dependency whose source_group is NOT a parent of the scoring group. "
        "For example, for group 3.5.2, parent groups are {\"3.5\", \"3\"}, so a dependency on source_group "
        "\"3.5.1\" is classified as a sibling dependency."
    )
    doc.add_heading("Modified function: prepare_answers_for_scoring()", level=4)
    doc.add_paragraph(
        "After the existing parent dependency extraction, now calls get_sibling_dependencies() and ensures "
        "all sibling dependency answers present in the provided payload are included in the enhanced "
        "answers dict. This means: if the caller includes 3.5.1.1 in the same request, it will be "
        "preserved for the scoring function. If the caller does not include it, the function does not "
        "attempt to fetch it from external storage."
    )

    doc.add_heading("3.4 TESTING_GUIDE.md — API Documentation", level=3)
    doc.add_paragraph(
        "Added a new section \"Scoring Groups with Sibling Dependencies (row_source)\" with:"
    )
    doc.add_paragraph("Two minimal curl request examples (group route + /score endpoint)", style="List Bullet")
    doc.add_paragraph("A behavior table showing penalty trigger conditions", style="List Bullet")
    doc.add_paragraph("Explanation that the API is stateless and does not auto-fetch sibling answers", style="List Bullet")

    doc.add_heading("3.5 Tests", level=3)
    doc.add_paragraph("File: test_scoring_3_5_2.py — 8 tests:")
    test_list_352 = [
        "test_row_source_dep_question_constant — ROW_SOURCE_DEP_QUESTION == '3.5.1.1'",
        "test_schema_extra_allow — model_config extra == 'allow'",
        "test_schema_declares_row_source_dependency — GROUP_DEPENDENCIES has row_source entry",
        "test_scoring_with_row_source_penalty — 2 expected, 1 submitted -> disclosure < max",
        "test_scoring_without_row_source_no_penalty — no 3.5.1.1 -> no penalty",
        "test_scoring_full_rows_no_penalty — 1 expected, 1 submitted -> same as no-penalty",
        "test_answer_utils_injects_sibling_dependency — prepare_answers retains 3.5.1.1",
        "test_group_route_requires_sibling_dependency_in_same_payload — documents stateless design",
    ]
    for t in test_list_352:
        doc.add_paragraph(t, style="List Bullet")

    doc.add_paragraph("\nFile: test_scoring_3_5_3.py — 5 tests:")
    test_list_353 = [
        "test_row_source_dep_question_constant — ROW_SOURCE_DEP_QUESTION == '3.5.1.1'",
        "test_schema_extra_allow — model_config extra == 'allow'",
        "test_schema_declares_row_source_dependency — GROUP_DEPENDENCIES has row_source entry",
        "test_scoring_with_row_source_penalty — 2 tax items expected, 1 submitted -> penalty",
        "test_scoring_without_row_source_no_penalty — no 3.5.1.1 -> no penalty",
    ]
    for t in test_list_353:
        doc.add_paragraph(t, style="List Bullet")

    # --- Section 4 ---
    doc.add_heading("4. Known Limitation (By Design)", level=2)
    doc.add_paragraph(
        "Group-specific score routes (e.g., /score/3.5.2) do not automatically fetch sibling dependency "
        "answers from persistence. This is by design for a stateless API. Callers must provide sibling "
        "answers in the same request using one of two methods:"
    )
    doc.add_paragraph(
        "Group route: include '3.5.1.1' directly in the answers dict",
        style="List Bullet",
    )
    doc.add_paragraph(
        "Schema-validated /score endpoint: pass dependency_answers with "
        '[{"group_id": "3.5.1", "3.5.1.1": [...]}]',
        style="List Bullet",
    )
    doc.add_paragraph(
        "This limitation is documented in TESTING_GUIDE.md and enforced by test "
        "test_group_route_requires_sibling_dependency_in_same_payload."
    )

    # --- Section 5 ---
    doc.add_heading("5. Test Results", level=2)
    doc.add_paragraph("13 new tests: all passed (pytest, Python 3.11.13)")
    doc.add_paragraph("231 existing tests: all passed (no regressions)")
    doc.add_paragraph(
        "1 pre-existing failure (test_scoring_2_2_2 — missing google.generativeai module) "
        "and 1 collection error (test_api_group_1_4 — missing fastapi module) are unrelated to this change."
    )

    # --- Section 6 ---
    doc.add_heading("6. Conclusion", level=2)
    doc.add_paragraph(
        "This Phase 2 change closes the API/schema/test gaps left by Phase 1. The row_source scoring "
        "mechanism for groups 3.5.2 and 3.5.3 is now fully functional end-to-end: schemas accept "
        "row-prefixed payloads, dependencies are declared and propagated, the answer preparation utility "
        "preserves sibling answers, and the behavior is documented and regression-tested."
    )

    doc.save(path)
    print(f"Saved: {path}")


def build_cn(path):
    doc = Document()
    style = doc.styles["Normal"]
    style.font.name = "Calibri"
    style.font.size = Pt(10)

    doc.add_heading(
        "变更报告（Phase 2）— Schema、依赖传播与 API 一致性修复\n"
        "CDP 3.5.2 / 3.5.3 row_source 组",
        level=1,
    )

    p = doc.add_paragraph()
    p.add_run("日期：").bold = True
    p.add_run("2026-03-08\n")
    p.add_run("范围：").bold = True
    p.add_run("评分组 3.5.2（ETS）和 3.5.3（碳税）— Schema 接纳、同级依赖传播、"
              "答案准备工具、测试、文档\n")
    p.add_run("与 Phase 1 的关系：").bold = True
    p.add_run("Phase 1（change_report_CN.md）实现了编译器和生成评分函数中的核心 row_source 评分逻辑。"
              "Phase 2 补齐了 API/Schema/测试层面的剩余缺口。")

    # --- Section 1 ---
    doc.add_heading("1. 解决的问题", level=2)
    doc.add_paragraph(
        "Phase 1 完成了评分引擎的变更（编译器、生成器、评分函数）。"
        "但仍有三个缺口导致 API 无法被外部调用方完整使用：",
        style="List Bullet",
    )
    doc.add_paragraph(
        "问题 A — Schema 拒绝行式键：group_3_5_2.py 和 group_3_5_3.py 的 Pydantic model_config "
        "使用 extra: \"forbid\"，会拒绝 \"3.5.2.Row 1.3.5.2.1\" 等行前缀键，导致无法通过 "
        "Schema 验证的 /score 端点提交多行 payload。对比之下，group_7_30_16.py（另一个多行组）"
        "已正确设置为 extra: \"allow\"。",
        style="List Bullet",
    )
    doc.add_paragraph(
        "问题 B — 同级依赖声明缺失：3.5.2 和 3.5.3 的 Schema 文件中 GROUP_DEPENDENCIES 仅声明了"
        "父级依赖（3.5.0.1，来自组 3.5），未声明 row_source 同级依赖（3.5.1.1，来自组 3.5.1），"
        "API 的依赖解析逻辑无从知晓需要该依赖。",
        style="List Bullet",
    )
    doc.add_paragraph(
        "问题 C — answer_utils 仅处理父级依赖：prepare_answers_for_scoring() 遍历父级组"
        "（如 3.5 → 3），但不处理同级组（3.5.1）。即使 3.5.1.1 包含在同一请求 payload 中，"
        "该函数也不会将其作为依赖特别保留。",
        style="List Bullet",
    )

    # --- Section 2 ---
    doc.add_heading("2. 变更文件清单", level=2)
    add_table(
        doc,
        ["文件", "类型", "变更内容"],
        [
            ["backend/compiler/schema_generator.py", "修改",
             "is_multi_row 检测增加 row_source；依赖生成增加 row_source 同级依赖"],
            ["backend/api/schemas/groups/group_3_5_2.py", "修改",
             "extra: \"forbid\" → \"allow\"；GROUP_DEPENDENCIES 添加 3.5.1.1（reason: row_source）"],
            ["backend/api/schemas/groups/group_3_5_3.py", "修改",
             "同 group_3_5_2.py"],
            ["backend/api/answer_utils.py", "修改",
             "新增 get_sibling_dependencies()；prepare_answers_for_scoring() 注入同级依赖"],
            ["backend/api/test_requests/TESTING_GUIDE.md", "修改",
             "新增 row_source 同级依赖的接口说明及最小请求示例"],
            ["backend/tests/questions/test_scoring_3_5_2.py", "新建",
             "8 个测试：Schema、依赖、评分罚分、answer_utils、无状态行为"],
            ["backend/tests/questions/test_scoring_3_5_3.py", "新建",
             "5 个测试：Schema、依赖、评分罚分"],
        ],
    )

    # --- Section 3 ---
    doc.add_heading("3. 变更详情", level=2)

    doc.add_heading("3.1 Schema 生成器 — 根因修复", level=3)
    doc.add_paragraph("文件：backend/compiler/schema_generator.py")
    doc.add_heading("3.1a is_multi_row 检测", level=4)
    doc.add_paragraph("原始：")
    doc.add_paragraph(
        'is_multi_row = any(\n'
        '    q.question_type and "multi-row" in q.question_type.lower()\n'
        '    for q in questions\n'
        ')',
        style="No Spacing",
    )
    doc.add_paragraph("修改后：")
    doc.add_paragraph(
        'is_multi_row = any(\n'
        '    (q.question_type and "multi-row" in q.question_type.lower())\n'
        '    or getattr(q, \'row_source\', None)\n'
        '    for q in questions\n'
        ')',
        style="No Spacing",
    )
    doc.add_paragraph(
        "原因：3.5.2 和 3.5.3 通过 row_source（而非 question_type=\"multi-row\"）定义多行结构。"
        "不加此检测，生成器会将其视为平面组，在 Schema 中输出 extra: \"forbid\"。"
    )

    doc.add_heading("3.1b row_source 依赖生成", level=4)
    doc.add_paragraph(
        "在现有字段依赖循环之后，新增代码检查每个问题的 row_source 属性。"
        "若 row_source 存在，提取父级问题编号（如从 \"3.5.1.1:contains=ETS\" 中提取 \"3.5.1.1\"）"
        "及其来源组（\"3.5.1\"），追加一条 reason=\"row_source\" 的字段依赖到 GROUP_DEPENDENCIES。"
        "会检查去重。"
    )
    doc.add_paragraph(
        "原因：不加此项，重新编译会生成不含同级依赖的 Schema 文件，导致手动修复丢失。"
    )

    doc.add_heading("3.2 Schema 文件 — 生成输出修复", level=3)
    doc.add_paragraph("文件：group_3_5_2.py、group_3_5_3.py")
    add_table(
        doc,
        ["属性", "原始", "修改后"],
        [
            ["model_config[\"extra\"]", "\"forbid\"", "\"allow\""],
            ["GROUP_DEPENDENCIES.fields", "仅 3.5.0.1（conditional_on）",
             "3.5.0.1（conditional_on）+ 3.5.1.1（row_source）"],
        ],
    )
    doc.add_paragraph(
        "这些文件是自动生成的。当前已手动修复；未来重新编译将因 3.1 的生成器修复而自动产生正确输出。"
    )

    doc.add_heading("3.3 answer_utils.py — 同级依赖注入", level=3)
    doc.add_paragraph("文件：backend/api/answer_utils.py")
    doc.add_heading("新函数：get_sibling_dependencies()", level=4)
    doc.add_paragraph(
        "动态导入给定评分组的 Schema 模块，读取 GROUP_DEPENDENCIES，返回所有 source_group 不属于"
        "该评分组父级的字段依赖。例如对组 3.5.2，父级组为 {\"3.5\", \"3\"}，因此对 source_group "
        "\"3.5.1\" 的依赖被归类为同级依赖。"
    )
    doc.add_heading("修改函数：prepare_answers_for_scoring()", level=4)
    doc.add_paragraph(
        "在现有的父级依赖提取之后，调用 get_sibling_dependencies()，确保 payload 中存在的所有"
        "同级依赖答案被保留在增强后的答案字典中。即：如果调用方在同一请求中包含了 3.5.1.1，"
        "它将被保留给评分函数。如果调用方未包含，函数不会尝试从外部存储获取。"
    )

    doc.add_heading("3.4 TESTING_GUIDE.md — API 文档", level=3)
    doc.add_paragraph("新增 \"Scoring Groups with Sibling Dependencies (row_source)\" 章节，包含：")
    doc.add_paragraph("两个最小 curl 请求示例（组路由 + /score 端点）", style="List Bullet")
    doc.add_paragraph("行为表格，展示罚分触发条件", style="List Bullet")
    doc.add_paragraph("说明 API 为无状态设计，不自动获取同级答案", style="List Bullet")

    doc.add_heading("3.5 测试", level=3)
    doc.add_paragraph("文件：test_scoring_3_5_2.py — 8 个测试：")
    test_list_352 = [
        "test_row_source_dep_question_constant — ROW_SOURCE_DEP_QUESTION == '3.5.1.1'",
        "test_schema_extra_allow — model_config extra == 'allow'",
        "test_schema_declares_row_source_dependency — GROUP_DEPENDENCIES 含 row_source 条目",
        "test_scoring_with_row_source_penalty — 期望 2 行、提交 1 行 → disclosure < max",
        "test_scoring_without_row_source_no_penalty — 无 3.5.1.1 → 不罚分",
        "test_scoring_full_rows_no_penalty — 期望 1 行、提交 1 行 → 与无罚分等同",
        "test_answer_utils_injects_sibling_dependency — prepare_answers 保留 3.5.1.1",
        "test_group_route_requires_sibling_dependency_in_same_payload — 记录无状态设计",
    ]
    for t in test_list_352:
        doc.add_paragraph(t, style="List Bullet")

    doc.add_paragraph("\n文件：test_scoring_3_5_3.py — 5 个测试：")
    test_list_353 = [
        "test_row_source_dep_question_constant — ROW_SOURCE_DEP_QUESTION == '3.5.1.1'",
        "test_schema_extra_allow — model_config extra == 'allow'",
        "test_schema_declares_row_source_dependency — GROUP_DEPENDENCIES 含 row_source 条目",
        "test_scoring_with_row_source_penalty — 期望 2 个 tax 项、提交 1 行 → 罚分",
        "test_scoring_without_row_source_no_penalty — 无 3.5.1.1 → 不罚分",
    ]
    for t in test_list_353:
        doc.add_paragraph(t, style="List Bullet")

    # --- Section 4 ---
    doc.add_heading("4. 已知限制（设计如此）", level=2)
    doc.add_paragraph(
        "组级评分路由（如 /score/3.5.2）不会自动从持久层获取同级依赖答案。"
        "这是无状态 API 的设计选择。调用方必须通过以下两种方式之一在同一请求中提供同级答案："
    )
    doc.add_paragraph(
        "组路由：在 answers 字典中直接包含 '3.5.1.1'",
        style="List Bullet",
    )
    doc.add_paragraph(
        "Schema 验证的 /score 端点：通过 dependency_answers 传入 "
        '[{"group_id": "3.5.1", "3.5.1.1": [...]}]',
        style="List Bullet",
    )
    doc.add_paragraph(
        "此限制已在 TESTING_GUIDE.md 中记录，并由测试 "
        "test_group_route_requires_sibling_dependency_in_same_payload 固定。"
    )

    # --- Section 5 ---
    doc.add_heading("5. 测试结果", level=2)
    doc.add_paragraph("13 个新测试：全部通过（pytest，Python 3.11.13）")
    doc.add_paragraph("231 个已有测试：全部通过（无回归）")
    doc.add_paragraph(
        "1 个预先存在的失败（test_scoring_2_2_2 — 缺少 google.generativeai 模块）"
        "和 1 个收集错误（test_api_group_1_4 — 缺少 fastapi 模块）与本次变更无关。"
    )

    # --- Section 6 ---
    doc.add_heading("6. 结论", level=2)
    doc.add_paragraph(
        "Phase 2 补齐了 Phase 1 遗留的 API/Schema/测试缺口。3.5.2 和 3.5.3 的 row_source 评分机制"
        "现已端到端完整可用：Schema 接受行前缀 payload，依赖被正确声明和传播，答案准备工具保留"
        "同级答案，行为已记录并有回归测试覆盖。"
    )

    doc.save(path)
    print(f"Saved: {path}")


if __name__ == "__main__":
    en_path = os.path.join(OUTPUT_DIR, "change_report_phase2_EN.docx")
    cn_path = os.path.join(OUTPUT_DIR, "change_report_phase2_CN.docx")
    build_en(en_path)
    build_cn(cn_path)
