"""
Utility functions for preparing answers for scoring functions.

This module ensures that parent/dependency question answers are included
when scoring a group, so visibility checks can work correctly.
Includes sibling dependency injection for row_source groups.
"""

from typing import Dict, Any, Set, List, Optional


def get_parent_scoring_groups(scoring_group: str) -> Set[str]:
    """
    Get all parent scoring groups for a given scoring group.
    
    Examples:
        "4.3.1" -> {"4.3", "4"}
        "3.6.2" -> {"3.6", "3"}
        "2.2.1" -> {"2.2", "2"}
        "1.4" -> {"1"}
        "3" -> set()  # Top-level, no parents
    
    Args:
        scoring_group: The scoring group identifier (e.g., "4.3.1")
    
    Returns:
        Set of parent scoring group identifiers
    """
    parts = scoring_group.split('.')
    parent_groups = set()
    
    # Generate all possible parent groups by removing trailing segments
    for i in range(len(parts) - 1, 0, -1):
        parent = '.'.join(parts[:i])
        parent_groups.add(parent)
    
    return parent_groups


def extract_dependency_answers(
    scoring_group: str,
    all_answers: Dict[str, Any],
    current_answers: Dict[str, Any]
) -> Dict[str, Any]:
    """
    Extract and include all parent/dependency question answers needed for scoring.
    
    This ensures that when scoring a group, all questions it depends on for
    conditional visibility are available in the answers dict.
    
    Args:
        scoring_group: The scoring group being scored (e.g., "4.3.1")
        all_answers: Complete dictionary of all answers (may contain more than needed)
        current_answers: Current answers dict (usually filtered to scoring_group)
    
    Returns:
        Enhanced answers dict including parent group answers
    """
    # Start with current answers
    enhanced_answers = dict(current_answers)
    
    # Get parent scoring groups
    parent_groups = get_parent_scoring_groups(scoring_group)
    
    # Include all answers from parent groups
    for parent_group in parent_groups:
        # Look for answers that match the parent group pattern
        # Format: {parent_group}.* or {parent_group}.Row {N}.*
        parent_prefix = f"{parent_group}."
        
        for key, value in all_answers.items():
            # Match direct parent group answers (e.g., "4.3.0.1")
            if key.startswith(parent_prefix):
                # Don't overwrite if already in current_answers
                if key not in enhanced_answers:
                    enhanced_answers[key] = value
            # Match row-based parent group answers (e.g., "4.3.Row 1.4.3.0.1")
            elif f".{parent_group}." in key or key.startswith(f"{parent_group}.Row "):
                if key not in enhanced_answers:
                    enhanced_answers[key] = value
    
    return enhanced_answers


def get_sibling_dependencies(scoring_group: str) -> List[Dict[str, str]]:
    """
    Get sibling (non-parent) dependencies declared in GROUP_DEPENDENCIES for a group.

    These are typically row_source dependencies where e.g. 3.5.2 needs 3.5.1.1's answer
    to determine expected rows.

    Returns:
        List of dependency dicts with question_number, source_group, reason
    """
    try:
        # Dynamically load the schema module for this group
        module_name = f"backend.api.schemas.groups.group_{scoring_group.replace('.', '_')}"
        import importlib
        module = importlib.import_module(module_name)
        group_deps = getattr(module, 'GROUP_DEPENDENCIES', {})

        parent_groups = get_parent_scoring_groups(scoring_group)
        sibling_deps = []
        for field_dep in group_deps.get('fields', []):
            source_group = field_dep.get('source_group', '')
            # A sibling dependency is one whose source_group is NOT a parent of scoring_group
            if source_group and source_group not in parent_groups:
                sibling_deps.append(field_dep)
        return sibling_deps
    except (ImportError, AttributeError):
        return []


def prepare_answers_for_scoring(
    scoring_group: str,
    provided_answers: Dict[str, Any]
) -> Dict[str, Any]:
    """
    Prepare answers dictionary for scoring a specific group.

    This automatically includes parent/dependency answers and sibling
    dependency answers (e.g., row_source) so that conditional visibility
    checks and row penalty scoring work correctly.

    Args:
        scoring_group: The scoring group identifier (e.g., "4.3.1")
        provided_answers: Answers provided in the request

    Returns:
        Enhanced answers dict with parent and sibling dependencies included
    """
    # Include parent group answers
    enhanced = extract_dependency_answers(
        scoring_group=scoring_group,
        all_answers=provided_answers,
        current_answers=provided_answers
    )

    # Include sibling dependency answers (e.g., row_source: 3.5.1.1 for group 3.5.2)
    sibling_deps = get_sibling_dependencies(scoring_group)
    for dep in sibling_deps:
        q_num = dep.get('question_number', '')
        source_group = dep.get('source_group', '')
        if q_num and q_num not in enhanced:
            # Check if the answer is in provided_answers directly
            if q_num in provided_answers:
                enhanced[q_num] = provided_answers[q_num]
            else:
                # Also check for source_group prefixed keys
                prefix = f"{source_group}."
                for key, value in provided_answers.items():
                    if key.startswith(prefix) and key not in enhanced:
                        enhanced[key] = value

    return enhanced

