# CDP Scoring API - Testing Guide

This guide provides instructions for testing the CDP Scoring API locally.

## Table of Contents
- [Starting the Server](#starting-the-server)
- [API Endpoints](#api-endpoints)
- [Testing Scoring](#testing-scoring)
- [Testing with Python](#testing-with-python)
- [Troubleshooting](#troubleshooting)

---

## Starting the Server

### Recommended Method

```bash
cd /Users/silver/CodeStorage/CDP_questions
python main.py
```

### Alternative: Using uvicorn directly

```bash
cd /Users/silver/CodeStorage/CDP_questions
python -m uvicorn backend.api.main:app --reload --host 0.0.0.0 --port 8000
```

**Server URL:** `http://localhost:8000`

**API Documentation:** `http://localhost:8000/docs` (Swagger UI)

---

## API Endpoints

### Health Check

```bash
curl http://localhost:8000/health
```

Response:
```json
{
  "status": "healthy",
  "service": "CDP Scoring API",
  "version": "2.0.0",
  "timestamp": "2025-01-16T12:00:00Z"
}
```

### List Available Scoring Groups

```bash
# Simple list of group IDs
curl http://localhost:8000/question-format/groups

# Detailed list with metadata
curl http://localhost:8000/question-format/all
```

### Get Schema for a Scoring Group

```bash
# Get Pydantic schema with dependencies (recommended)
curl http://localhost:8000/question-format/schema/3.1.1

# Get JSON Schema Draft 7 (for TypeScript generation)
curl http://localhost:8000/question-format/3.1.1/json-schema
```

### Score Answers

The main scoring endpoint accepts any scoring group:

```bash
curl -X POST http://localhost:8000/score \
  -H "Content-Type: application/json" \
  -d '{
    "group_id": "3.1.1",
    "answers": {
      "3.1.1.1": "Yes",
      "3.1.1.2": "Climate change"
    }
  }'
```

Or use the group-specific endpoints:

```bash
curl -X POST http://localhost:8000/score/3.1.1 \
  -H "Content-Type: application/json" \
  -d '{
    "answers": {
      "3.1.1.1": "Yes",
      "3.1.1.2": "Climate change"
    }
  }'
```

---

## Testing Scoring

### Using Test JSON Files

Small test payloads (e.g. `02_score_group_3_1_1.json`) are in `backend/api/test_requests/`.

Company response files (formatted responses, scores, reports) are in `company_responses/<company>/` at project root:

```bash
# Score using a test file
curl -X POST http://localhost:8000/score/3.1.1 \
  -H "Content-Type: application/json" \
  -d @backend/api/test_requests/02_score_group_3_1_1.json
```

### Example: Complete Scoring Workflow

```bash
# 1. Check server health
curl http://localhost:8000/health

# 2. List available scoring groups
curl http://localhost:8000/question-format/groups

# 3. Get schema for a specific group
curl http://localhost:8000/question-format/schema/3.1.1

# 4. Submit answers for scoring
curl -X POST http://localhost:8000/score/3.1.1 \
  -H "Content-Type: application/json" \
  -d '{
    "answers": {
      "3.1.1.1": "Yes",
      "3.1.1.2": "Climate change"
    }
  }'
```

### Scoring Response Format

```json
{
  "group_id": "3.1.1",
  "disclosure": 1.0,
  "awareness": 0.5,
  "management": 0.0,
  "leadership": 0.0,
  "reasoning": "Disclosure: +1.0 for answering 3.1.1.1..."
}
```

---

## Testing with Python

```python
import requests

BASE_URL = "http://localhost:8000"

# Health check
response = requests.get(f"{BASE_URL}/health")
print(response.json())

# List available groups
response = requests.get(f"{BASE_URL}/question-format/groups")
groups = response.json()
print(f"Available groups: {groups}")

# Get schema for a group
response = requests.get(f"{BASE_URL}/question-format/schema/3.1.1")
schema = response.json()
print(f"Schema: {schema}")

# Score answers
score_request = {
    "answers": {
        "3.1.1.1": "Yes",
        "3.1.1.2": "Climate change"
    }
}
response = requests.post(f"{BASE_URL}/score/3.1.1", json=score_request)
scores = response.json()
print(f"Scores: {scores}")
```

---

## API Documentation

FastAPI provides interactive documentation:

- **Swagger UI:** http://localhost:8000/docs
- **ReDoc:** http://localhost:8000/redoc
- **OpenAPI Schema:** http://localhost:8000/openapi.json

---

## Troubleshooting

### Server won't start

```bash
# Check if port 8000 is in use
lsof -i :8000

# Kill the process if needed
kill -9 <PID>

# Try a different port
python -m uvicorn backend.api.main:app --reload --port 8080
```

### Import errors

```bash
# Ensure you're in the project root
cd /path/to/CDP_questions

# Activate virtual environment
source venv/bin/activate

# Install dependencies
pip install -r requirements.txt
```

### GEMINI_API_KEY not set

For AI-scored questions, set the API key:

```bash
export GEMINI_API_KEY='your-api-key-here'

# Or create a .env file
echo "GEMINI_API_KEY=your-api-key-here" > .env
```

---

## Response Codes

| Code | Meaning |
|------|---------|
| 200 | Success |
| 400 | Invalid request |
| 404 | Group not found |
| 422 | Validation error |
| 500 | Server error |

---

## Tips

- Use `jq` for pretty JSON: `curl ... | jq '.'`
- Check `/docs` for interactive API testing
- Start with `/health` to verify the server is running
- Use `/question-format/schema/{group_id}` to understand required fields before scoring

---

## Scoring Groups with Sibling Dependencies (row_source)

Some multi-row groups depend on a **sibling** question to determine the expected number of rows. For example:

- `3.5.2` (ETS details) expects one row per ETS selected in `3.5.1.1`
- `3.5.3` (Carbon tax details) expects one row per tax selected in `3.5.1.1`

The API does **not** auto-fetch sibling answers from persistence. Callers must provide them in the same request.

### Option 1: Group route — include sibling answer in `answers`

```bash
curl -X POST http://localhost:8000/score/3.5.2 \
  -H "Content-Type: application/json" \
  -d '{
    "answers": {
      "3.5.0.1": "Yes",
      "3.5.1.1": ["EU ETS", "Korea ETS"],
      "3.5.2.Row 1.3.5.2.0": "EU ETS",
      "3.5.2.Row 1.3.5.2.1": 50.0,
      "3.5.2.Row 1.3.5.2.2": 30.0,
      "3.5.2.Row 1.3.5.2.3": "2024-01-01",
      "3.5.2.Row 1.3.5.2.4": "2024-12-31",
      "3.5.2.Row 2.3.5.2.0": "Korea ETS",
      "3.5.2.Row 2.3.5.2.1": 40.0,
      "3.5.2.Row 2.3.5.2.2": 20.0,
      "3.5.2.Row 2.3.5.2.3": "2024-01-01",
      "3.5.2.Row 2.3.5.2.4": "2024-12-31"
    }
  }'
```

### Option 2: Schema-validated `/score` endpoint — use `dependency_answers`

```bash
curl -X POST http://localhost:8000/score \
  -H "Content-Type: application/json" \
  -d '{
    "answers": {
      "group_id": "3.5.2",
      "3.5.2.Row 1.3.5.2.0": "EU ETS",
      "3.5.2.Row 1.3.5.2.1": 50.0,
      "3.5.2.Row 1.3.5.2.2": 30.0,
      "3.5.2.Row 1.3.5.2.3": "2024-01-01",
      "3.5.2.Row 1.3.5.2.4": "2024-12-31"
    },
    "dependency_answers": [
      {"group_id": "3.5", "3.5.0.1": "Yes"},
      {"group_id": "3.5.1", "3.5.1.1": ["EU ETS", "Korea ETS"]}
    ]
  }'
```

### How row_source penalty works

| `3.5.1.1` provided? | ETS selected | Rows submitted | Penalty? |
|---------------------|-------------|---------------|----------|
| No                  | N/A         | 1             | No — no expected count known |
| Yes                 | 2           | 2             | No — all expected rows present |
| Yes                 | 2           | 1             | Yes — missing row scores 0, disclosure halved |

The same pattern applies to `3.5.3` (carbon tax, filtered by `contains=tax` in `3.5.1.1`)
