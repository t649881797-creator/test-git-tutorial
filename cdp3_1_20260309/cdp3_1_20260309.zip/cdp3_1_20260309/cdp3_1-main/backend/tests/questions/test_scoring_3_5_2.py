"""
Test scoring group 3.5.2 - ETS details (row_source dependency on 3.5.1.1).

3.5.2 is a multi-row group where each row corresponds to an ETS selected
in 3.5.1.1. The row_source mechanism means:
- If 3.5.1.1 selects 2 ETS systems, 3.5.2 expects 2 rows
- Missing rows get a disclosure penalty (score 0)
- The schema must accept row-prefixed keys (extra="allow")

These tests verify:
1. Schema allows row-prefixed keys (extra="allow")
2. GROUP_DEPENDENCIES includes the row_source sibling dependency on 3.5.1
3. Scoring with row_source: 2 expected rows, 1 submitted -> penalty
4. Scoring without row_source: no penalty applied
5. answer_utils injects sibling dependencies
"""
import pytest

from backend.scoring.scoring_group_3_5_2 import (
    score_group_3_5_2,
    get_max_scores_3_5_2,
    ROW_SOURCE_DEP_QUESTION,
)


def test_row_source_dep_question_constant():
    """ROW_SOURCE_DEP_QUESTION should point to 3.5.1.1."""
    assert ROW_SOURCE_DEP_QUESTION == '3.5.1.1'


def test_schema_extra_allow():
    """Schema must use extra='allow' to accept row-prefixed keys."""
    from backend.api.schemas.groups.group_3_5_2 import Group3_5_2Schema
    assert Group3_5_2Schema.model_config.get("extra") == "allow"


def test_schema_declares_row_source_dependency():
    """GROUP_DEPENDENCIES must declare 3.5.1.1 from source_group 3.5.1."""
    from backend.api.schemas.groups.group_3_5_2 import GROUP_DEPENDENCIES

    fields = GROUP_DEPENDENCIES.get("fields", [])
    row_source_deps = [
        f for f in fields
        if isinstance(f, dict) and f.get("reason") == "row_source"
    ]
    assert len(row_source_deps) >= 1, "Must declare at least one row_source dependency"
    assert row_source_deps[0]["question_number"] == "3.5.1.1"
    assert row_source_deps[0]["source_group"] == "3.5.1"


def test_scoring_with_row_source_penalty():
    """
    When 3.5.1.1 selects 2 ETS systems but only 1 row is submitted,
    disclosure should be penalized (lower than full score).
    """
    answers = {
        # Parent gate
        "3.5.0.1": "Yes",
        # Sibling dependency: 2 ETS systems selected
        "3.5.1.1": ["EU ETS", "Korea ETS"],
        # Only 1 row submitted
        "3.5.2.Row 1.3.5.2.0": "EU ETS",
        "3.5.2.Row 1.3.5.2.1": 50.0,
        "3.5.2.Row 1.3.5.2.2": 30.0,
        "3.5.2.Row 1.3.5.2.3": "2024-01-01",
        "3.5.2.Row 1.3.5.2.4": "2024-12-31",
    }
    result = score_group_3_5_2(answers)
    if isinstance(result, tuple):
        scores = result[0]
    else:
        scores = result
    # With 2 expected and 1 submitted, disclosure should be penalized
    max_scores = get_max_scores_3_5_2()
    assert scores["disclosure"] < max_scores["disclosure"], (
        "Disclosure should be less than max when missing expected rows"
    )


def test_scoring_without_row_source_no_penalty():
    """
    When 3.5.1.1 is not provided, no row_source penalty is applied.
    A single row should get full disclosure for that row.
    """
    answers = {
        "3.5.0.1": "Yes",
        # No 3.5.1.1 -> no expected rows -> no penalty
        "3.5.2.Row 1.3.5.2.0": "EU ETS",
        "3.5.2.Row 1.3.5.2.1": 50.0,
        "3.5.2.Row 1.3.5.2.2": 30.0,
        "3.5.2.Row 1.3.5.2.3": "2024-01-01",
        "3.5.2.Row 1.3.5.2.4": "2024-12-31",
    }
    result = score_group_3_5_2(answers)
    if isinstance(result, tuple):
        scores = result[0]
    else:
        scores = result
    # Without row_source constraint, the single row should score normally
    assert scores["disclosure"] > 0.0


def test_scoring_full_rows_no_penalty():
    """
    When 3.5.1.1 selects 1 ETS and 1 row is submitted, no penalty.
    """
    answers = {
        "3.5.0.1": "Yes",
        "3.5.1.1": ["EU ETS"],
        "3.5.2.Row 1.3.5.2.0": "EU ETS",
        "3.5.2.Row 1.3.5.2.1": 50.0,
        "3.5.2.Row 1.3.5.2.2": 30.0,
        "3.5.2.Row 1.3.5.2.3": "2024-01-01",
        "3.5.2.Row 1.3.5.2.4": "2024-12-31",
    }
    result_with = score_group_3_5_2(answers)
    if isinstance(result_with, tuple):
        scores_with = result_with[0]
    else:
        scores_with = result_with

    # Same without row_source
    answers_no_rs = dict(answers)
    del answers_no_rs["3.5.1.1"]
    result_without = score_group_3_5_2(answers_no_rs)
    if isinstance(result_without, tuple):
        scores_without = result_without[0]
    else:
        scores_without = result_without

    # With 1 expected and 1 submitted, disclosure should equal no-penalty score
    assert scores_with["disclosure"] == scores_without["disclosure"]


def test_answer_utils_injects_sibling_dependency():
    """
    prepare_answers_for_scoring should include sibling dep answers
    when they exist in the provided payload.
    """
    from backend.api.answer_utils import prepare_answers_for_scoring

    provided = {
        "3.5.2.Row 1.3.5.2.0": "EU ETS",
        "3.5.1.1": ["EU ETS", "Korea ETS"],
    }
    enhanced = prepare_answers_for_scoring("3.5.2", provided)
    assert "3.5.1.1" in enhanced, (
        "prepare_answers_for_scoring must retain 3.5.1.1 sibling dependency"
    )


def test_group_route_requires_sibling_dependency_in_same_payload():
    """
    Group route /score/3.5.2 does NOT auto-fetch sibling dependency from
    persistence. Callers must include 3.5.1.1 in the same request payload.

    Without 3.5.1.1, the row_source penalty cannot determine expected rows,
    so it defaults to no penalty (treats all submitted rows as complete).
    This is by design for a stateless API — not a bug.

    To provide sibling answers, callers have two options:
      1. Group route: include '3.5.1.1' directly in the answers dict
      2. Schema-validated /score endpoint: pass dependency_answers with
         [{"group_id": "3.5.1", "3.5.1.1": ["EU ETS", "Korea ETS"]}]
    """
    # Payload WITHOUT sibling dependency — no penalty possible
    answers_no_sibling = {
        "3.5.0.1": "Yes",
        "3.5.2.Row 1.3.5.2.0": "EU ETS",
        "3.5.2.Row 1.3.5.2.1": 50.0,
    }
    result_no = score_group_3_5_2(answers_no_sibling)
    scores_no = result_no[0] if isinstance(result_no, tuple) else result_no

    # Payload WITH sibling dependency — penalty kicks in
    answers_with_sibling = dict(answers_no_sibling)
    answers_with_sibling["3.5.1.1"] = ["EU ETS", "Korea ETS"]
    result_with = score_group_3_5_2(answers_with_sibling)
    scores_with = result_with[0] if isinstance(result_with, tuple) else result_with

    # The caller who provides 3.5.1.1 gets a lower score (missing row penalty)
    assert scores_with["disclosure"] < scores_no["disclosure"], (
        "Providing 3.5.1.1 with 2 ETS but only 1 row should trigger penalty. "
        "Without 3.5.1.1, no penalty is applied — this is the expected stateless behavior."
    )
