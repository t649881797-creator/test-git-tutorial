"""
Test scoring group 3.5.3 - Carbon tax details (row_source dependency on 3.5.1.1).

3.5.3 is a multi-row group where each row corresponds to a carbon tax selected
in 3.5.1.1. The row_source mechanism filters for items containing 'tax'.

These tests verify:
1. Schema allows row-prefixed keys (extra="allow")
2. GROUP_DEPENDENCIES includes the row_source sibling dependency on 3.5.1
3. Scoring with row_source: expected tax rows vs submitted
4. answer_utils injects sibling dependencies
"""
import pytest

from backend.scoring.scoring_group_3_5_3 import (
    score_group_3_5_3,
    get_max_scores_3_5_3,
    ROW_SOURCE_DEP_QUESTION,
)


def test_row_source_dep_question_constant():
    """ROW_SOURCE_DEP_QUESTION should point to 3.5.1.1."""
    assert ROW_SOURCE_DEP_QUESTION == '3.5.1.1'


def test_schema_extra_allow():
    """Schema must use extra='allow' to accept row-prefixed keys."""
    from backend.api.schemas.groups.group_3_5_3 import Group3_5_3Schema
    assert Group3_5_3Schema.model_config.get("extra") == "allow"


def test_schema_declares_row_source_dependency():
    """GROUP_DEPENDENCIES must declare 3.5.1.1 from source_group 3.5.1."""
    from backend.api.schemas.groups.group_3_5_3 import GROUP_DEPENDENCIES

    fields = GROUP_DEPENDENCIES.get("fields", [])
    row_source_deps = [
        f for f in fields
        if isinstance(f, dict) and f.get("reason") == "row_source"
    ]
    assert len(row_source_deps) >= 1
    assert row_source_deps[0]["question_number"] == "3.5.1.1"
    assert row_source_deps[0]["source_group"] == "3.5.1"


def test_scoring_with_row_source_penalty():
    """
    When 3.5.1.1 selects 2 tax systems but only 1 row submitted,
    disclosure should be penalized.
    """
    answers = {
        "3.5.0.1": "Yes",
        "3.5.1.1": ["Japan carbon tax", "South Africa carbon tax"],
        "3.5.3.Row 1.3.5.3.0": "Japan carbon tax",
        "3.5.3.Row 1.3.5.3.1": "2024-01-01",
        "3.5.3.Row 1.3.5.3.2": "2024-12-31",
        "3.5.3.Row 1.3.5.3.3": 80.0,
        "3.5.3.Row 1.3.5.3.4": 50000.0,
    }
    result = score_group_3_5_3(answers)
    if isinstance(result, tuple):
        scores = result[0]
    else:
        scores = result
    max_scores = get_max_scores_3_5_3()
    assert scores["disclosure"] < max_scores["disclosure"]


def test_scoring_without_row_source_no_penalty():
    """Without 3.5.1.1, no row_source penalty is applied."""
    answers = {
        "3.5.0.1": "Yes",
        "3.5.3.Row 1.3.5.3.0": "Japan carbon tax",
        "3.5.3.Row 1.3.5.3.1": "2024-01-01",
        "3.5.3.Row 1.3.5.3.2": "2024-12-31",
        "3.5.3.Row 1.3.5.3.3": 80.0,
        "3.5.3.Row 1.3.5.3.4": 50000.0,
    }
    result = score_group_3_5_3(answers)
    if isinstance(result, tuple):
        scores = result[0]
    else:
        scores = result
    assert scores["disclosure"] > 0.0
