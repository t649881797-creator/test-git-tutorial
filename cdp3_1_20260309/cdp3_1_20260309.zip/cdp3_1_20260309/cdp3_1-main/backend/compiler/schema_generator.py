"""Generate Pydantic schemas from JSON classification/conditional files.

This generator reads from:
- classificationOptions/module_*/classification_*.json (812 files)
- conditionalJSON/module_*/scoring_*.json (212 files)
- CDP_scoring_questions.xlsx (spreadsheet with question metadata)

And generates:
- backend/api/schemas/groups/group_*.py (one per scoring group, with inline enums)
- backend/api/schemas/groups/__init__.py (exports all group schemas)
- backend/api/schemas/__init__.py (GroupData discriminated union)
"""

import json
import re
from collections import defaultdict
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple


# =============================================================================
# Data Structures
# =============================================================================


@dataclass
class EnumSpec:
    """Enum specification."""

    name: str  # e.g., "Q1_1Options"
    values: List[str]  # Original option strings
    python_values: Dict[str, str] = field(default_factory=dict)  # NAME: "value"

    def __post_init__(self):
        if not self.python_values:
            self.python_values = self._options_to_python_names(self.values)

    @staticmethod
    def _options_to_python_names(options: List[str]) -> Dict[str, str]:
        """Convert option strings to valid Python enum names."""
        result = {}
        seen = set()

        for opt in options:
            # Clean and convert to valid Python identifier
            name = opt.upper()
            # Replace special chars with underscore
            name = re.sub(r"[^A-Z0-9]", "_", name)
            # Remove consecutive underscores
            name = re.sub(r"_+", "_", name)
            # Remove leading/trailing underscores
            name = name.strip("_")
            # Ensure it starts with letter
            if name and not name[0].isalpha():
                name = "OPT_" + name
            # Handle empty
            if not name:
                name = "EMPTY"

            # Handle duplicates
            base_name = name
            counter = 1
            while name in seen:
                name = f"{base_name}_{counter}"
                counter += 1
            seen.add(name)

            result[name] = opt

        return result


@dataclass
class FieldSpec:
    """Schema field specification."""

    name: str  # Field name (sanitized question_number)
    alias: str  # Original question number (e.g., "1.1.1")
    python_type: str  # str, int, float, List[str], Optional[EnumName]
    enum_spec: Optional[EnumSpec] = None  # Inline enum if applicable
    is_list: bool = False  # Whether this is a List type
    is_optional: bool = True  # Always True for answers
    max_length: Optional[int] = None  # For text_field types
    description: Optional[str] = None


@dataclass
class QuestionInfo:
    """Question info derived from classification JSON file or spreadsheet."""

    question_number: str  # e.g., "4.3.1.2"
    classification_path: Optional[Path] = None
    classification_data: Dict[str, Any] = field(default_factory=dict)
    # Additional fields from spreadsheet for non-classification types
    question_type: str = "classification"  # date, numeric, text_field, classification
    question_text: str = ""
    max_length: Optional[int] = None  # For text_field types


@dataclass
class FieldDependency:
    """A dependency on a field from another scoring group."""
    
    question_number: str  # e.g., "2.2.1.1"
    source_group: str  # e.g., "2.2.1"
    reason: str  # "conditional_on" or "dependency_check"


@dataclass
class ScoreDependency:
    """A dependency on another group's score."""
    
    group_id: str  # e.g., "2.2.2"
    category: str  # disclosure, awareness, management, or leadership
    requirement: str  # e.g., "full_points"


@dataclass
class GroupDependencies:
    """Dependencies for a scoring group."""
    
    fields: List[FieldDependency] = field(default_factory=list)
    scores: List[ScoreDependency] = field(default_factory=list)
    
    def is_empty(self) -> bool:
        return not self.fields and not self.scores


@dataclass
class GroupSchema:
    """Schema for one scoring group."""

    group_id: str  # e.g., "1.1"
    class_name: str  # e.g., "Group1_1Schema"
    fields: List[FieldSpec] = field(default_factory=list)
    questions: List[QuestionInfo] = field(default_factory=list)
    dependencies: GroupDependencies = field(default_factory=GroupDependencies)
    is_multi_row: bool = False  # True for groups that accept row-prefixed keys


# =============================================================================
# Schema Generator
# =============================================================================


class SchemaGenerator:
    """Generate Pydantic schemas from JSON directories (all 7 modules)."""

    # Fixed enums - common options that appear frequently
    # These will be defined inline in each file that needs them
    FIXED_ENUMS = {
        "Language": ["English", "Latin American Spanish", "Brazilian Portuguese",
                     "Japanese", "Chinese", "Other, please specify"],
        "YesNo": ["Yes", "No"],
        "YesNoUnknown": ["Yes", "No", "Unknown"],
        "Likelihood": ["Very likely", "Likely", "Possible", "Unlikely",
                      "Very unlikely", "Unknown"],
        "Magnitude": ["High", "Medium-high", "Medium", "Medium-low", "Low", "Unknown"],
        "TimeHorizon": ["Short-term", "Medium-term", "Long-term", "Unknown"],
        "EnvironmentalIssue": ["Climate change", "Forests", "Water",
                               "Plastics", "Biodiversity"],
    }

    def __init__(
        self,
        classification_dir: str = "classificationOptions",
        conditional_dir: str = "conditionalJSON",
        output_dir: str = "backend/api/schemas",
        spreadsheet_path: Optional[str] = None,
    ):
        self.classification_dir = Path(classification_dir)
        self.conditional_dir = Path(conditional_dir)
        self.output_dir = Path(output_dir)
        self.spreadsheet_path = spreadsheet_path
        self.group_schemas: Dict[str, GroupSchema] = {}

    def generate_all(self) -> Dict[str, Any]:
        """Generate all schemas from JSON directories."""
        # 1. Discover all scoring groups
        scoring_groups = self._discover_scoring_groups()
        print(f"Found {len(scoring_groups)} scoring groups across 7 modules")

        # 2. Map questions to scoring groups
        questions_by_group = self._map_questions_to_groups(scoring_groups)
        total_questions = sum(len(q) for q in questions_by_group.values())
        print(f"Mapped {total_questions} questions to groups")

        # 3. For each group: generate GroupSchema with inline enums
        for group_id in scoring_groups:
            questions = questions_by_group.get(group_id, [])
            self._generate_group_schema(group_id, questions)

        # 4. Write all generated files
        self._write_group_files()
        self._update_groups_init()
        self._update_schemas_init()

        return {
            "groups": len(self.group_schemas),
            "total_fields": sum(
                len(g.fields) for g in self.group_schemas.values()
            ),
        }

    def _discover_scoring_groups(self) -> List[str]:
        """Discover all scoring groups from conditionalJSON and spreadsheet."""
        groups = set()

        # 1. From conditionalJSON files
        if self.conditional_dir.exists():
            for f in self.conditional_dir.rglob("scoring_*.json"):
                # scoring_4_3_1.json -> 4.3.1
                group_id = f.stem.replace("scoring_", "").replace("_", ".")
                groups.add(group_id)

        # 2. From spreadsheet (to include groups without conditionalJSON)
            # Use provided spreadsheet_path or default to CDP_scoring_questions.xlsx
        spreadsheet_path = self.spreadsheet_path
        if not spreadsheet_path:
            default_path = Path("CDP_scoring_questions.xlsx")
            if default_path.exists():
                spreadsheet_path = str(default_path)
        
        if spreadsheet_path and Path(spreadsheet_path).exists():
            from .spreadsheet_parser import SpreadsheetParser

            parser = SpreadsheetParser(spreadsheet_path)
            all_questions = parser.parse_all()
            for q in all_questions:
                if q.scoring_group:
                    groups.add(str(q.scoring_group))

        return sorted(
            list(groups), key=lambda x: [int(p) if p.isdigit() else p for p in x.split(".")]
        )

    def _get_spreadsheet_question_types(self) -> Dict[str, str]:
        """Load question types from spreadsheet into a lookup dictionary."""
        # Use provided spreadsheet_path or default to CDP_scoring_questions.xlsx
        spreadsheet_path = self.spreadsheet_path
        if not spreadsheet_path:
            default_path = Path("CDP_scoring_questions.xlsx")
            if default_path.exists():
                spreadsheet_path = str(default_path)
            else:
                return {}
        
        if not Path(spreadsheet_path).exists():
            return {}
        
        from .spreadsheet_parser import SpreadsheetParser
        
        parser = SpreadsheetParser(spreadsheet_path)
        all_questions = parser.parse_all()
        
        return {
            q.question_number: (q.question_type or "classification").lower()
            for q in all_questions
        }

    def _map_questions_to_groups(
        self, scoring_groups: List[str]
    ) -> Dict[str, List[QuestionInfo]]:
        """Map questions to scoring groups from classification files and spreadsheet."""
        questions_by_group: Dict[str, List[QuestionInfo]] = defaultdict(list)
        seen_questions: Set[str] = set()
        
        # Load question types from spreadsheet to get correct types for classification questions
        spreadsheet_types = self._get_spreadsheet_question_types()

        # 1. Load classification files (existing behavior for classification types)
        if self.classification_dir.exists():
            for f in self.classification_dir.rglob("classification_*.json"):
                # classification_4_3_1_2.json -> 4.3.1.2
                q_num = f.stem.replace("classification_", "").replace("_", ".")

                # Load classification data
                data = json.loads(f.read_text())

                # Get actual question type from spreadsheet (may be "multi-row")
                question_type = spreadsheet_types.get(q_num, "classification")

                # Find which scoring group this belongs to (longest prefix match)
                for group in sorted(scoring_groups, key=len, reverse=True):
                    if q_num.startswith(group) or q_num == group:
                        questions_by_group[group].append(
                            QuestionInfo(
                                question_number=q_num,
                                classification_path=f,
                                classification_data=data,
                                question_type=question_type,
                            )
                        )
                        seen_questions.add(q_num)
                        break

        # 2. Load non-classification questions from spreadsheet (keyed by scoring_group)
        scoring_groups_set = set(scoring_groups)
        spreadsheet_questions_by_group = self._load_spreadsheet_questions()
        for group, questions in spreadsheet_questions_by_group.items():
            if group not in scoring_groups_set:
                continue
            for q in questions:
                # Create unique key: question_number + scoring_group
                unique_key = f"{q.question_number}:{group}"
                if unique_key not in seen_questions:
                    questions_by_group[group].append(q)
                    seen_questions.add(unique_key)

        return questions_by_group

    def _load_spreadsheet_questions(self) -> Dict[str, List[QuestionInfo]]:
        """Load questions from spreadsheet for non-classification types."""
        if not self.spreadsheet_path or not Path(self.spreadsheet_path).exists():
            return {}

        from .spreadsheet_parser import SpreadsheetParser

        parser = SpreadsheetParser(self.spreadsheet_path)
        all_questions = parser.parse_all()

        result: Dict[str, List[QuestionInfo]] = defaultdict(list)
        for q in all_questions:
            # Only include non-classification types
            q_type = q.question_type or "classification"
            if q_type.lower() in ("date", "numeric", "text_field", "attachment"):
                # Parse max_length from classification_options if text_field
                max_length = None
                if q_type.lower() == "text_field" and q.classification_options:
                    opts = q.classification_options
                    if isinstance(opts, str) and "Maximum" in opts:
                        match = re.search(r"Maximum\s+(\d+)\s+characters", opts)
                        if match:
                            max_length = int(match.group(1))

                scoring_group = str(q.scoring_group) if q.scoring_group else ""
                if scoring_group:
                    result[scoring_group].append(
                        QuestionInfo(
                            question_number=q.question_number,
                            classification_path=None,
                            classification_data={},
                            question_type=q_type.lower(),
                            question_text=q.question_text or "",
                            max_length=max_length,
                        )
                    )
        return result

    def _generate_group_schema(
        self, group_id: str, questions: List[QuestionInfo]
    ) -> None:
        """Generate schema for a scoring group."""
        class_name = f"Group{group_id.replace('.', '_')}Schema"
        
        # Extract dependencies for this group
        dependencies = self._extract_dependencies(group_id)
        
        # Detect if this is a multi-row group by checking question types or row_source
        is_multi_row = any(
            (q.question_type and "multi-row" in q.question_type.lower())
            or getattr(q, 'row_source', None)
            for q in questions
        )
        
        schema = GroupSchema(
            group_id=group_id,
            class_name=class_name,
            questions=questions,
            dependencies=dependencies,
            is_multi_row=is_multi_row,
        )

        for question in questions:
            field_specs = self._parse_question(question)
            schema.fields.extend(field_specs)

        self.group_schemas[group_id] = schema
    
    def _extract_dependencies(self, group_id: str) -> GroupDependencies:
        """Extract dependencies for a scoring group using DependencyExtractor."""
        try:
            from .dependency_extractor import DependencyExtractor
            
            extractor = DependencyExtractor(
                spreadsheet_path=str(self.spreadsheet_path) if self.spreadsheet_path else "CDP_scoring_questions.xlsx",
                conditional_json_dir=str(self.conditional_dir),
            )
            
            deps = extractor.extract_for_group(group_id)
            
            # Convert to local dataclasses
            field_deps = [
                FieldDependency(
                    question_number=f.question_number,
                    source_group=f.source_group,
                    reason=f.reason,
                )
                for f in deps.fields
            ]
            
            score_deps = [
                ScoreDependency(
                    group_id=s.group_id,
                    category=s.category,
                    requirement=s.requirement,
                )
                for s in deps.scores
            ]
            
            return GroupDependencies(fields=field_deps, scores=score_deps)
            
        except Exception as e:
            print(f"Warning: Could not extract dependencies for group {group_id}: {e}")
            return GroupDependencies()

    def _parse_question(self, question: QuestionInfo) -> List[FieldSpec]:
        """Parse a question's classification data into field specs."""
        data = question.classification_data
        q_num = question.question_number
        fields: List[FieldSpec] = []

        # Generate field name (q_1_2_3 format)
        field_name = f"q_{q_num.replace('.', '_')}"

        # Handle non-classification types from spreadsheet
        q_type_lower = question.question_type.lower() if question.question_type else ""

        if q_type_lower == "date":
            fields.append(
                FieldSpec(
                    name=field_name,
                    alias=q_num,
                    python_type="Optional[str]",  # Use str for dates to allow flexible input
                    description=question.question_text or f"Date field for {q_num}",
                )
            )
            return fields

        if q_type_lower == "numeric":
            fields.append(
                FieldSpec(
                    name=field_name,
                    alias=q_num,
                    python_type="Optional[float]",
                    description=question.question_text or f"Numeric field for {q_num}",
                )
            )
            return fields

        if q_type_lower == "text_field":
            fields.append(
                FieldSpec(
                    name=field_name,
                    alias=q_num,
                    python_type="Optional[str]",
                    max_length=question.max_length or 2500,
                    description=question.question_text or f"Text field for {q_num}",
                )
            )
            return fields

        if q_type_lower == "attachment":
            fields.append(
                FieldSpec(
                    name=field_name,
                    alias=q_num,
                    python_type="Optional[str]",
                    description=question.question_text or f"Attachment URL/path for {q_num}",
                )
            )
            return fields

        # Handle classification types from JSON files
        q_type = data.get("type", "")

        if q_type == "single_select":
            options = data.get("options", [])
            enum_spec = self._get_or_create_enum(q_num, options)

            if enum_spec:
                fields.append(
                    FieldSpec(
                        name=field_name,
                        alias=q_num,
                        python_type=f"Optional[{enum_spec.name}]",
                        enum_spec=enum_spec,
                    )
                )
            else:
                fields.append(
                    FieldSpec(
                        name=field_name,
                        alias=q_num,
                        python_type="Optional[str]",
                    )
                )

            # Add companion field for "Other, please specify"
            if any("Other" in opt for opt in options):
                fields.append(
                    FieldSpec(
                        name=f"{field_name}_other",
                        alias=f"{q_num}_other",
                        python_type="Optional[str]",
                        max_length=500,
                        description="If 'Other, please specify' selected",
                    )
                )

        elif q_type == "multiple_select":
            options = data.get("options", [])
            enum_spec = self._get_or_create_enum(q_num, options)

            if enum_spec:
                fields.append(
                    FieldSpec(
                        name=field_name,
                        alias=q_num,
                        python_type=f"Optional[List[{enum_spec.name}]]",
                        enum_spec=enum_spec,
                        is_list=True,
                    )
                )
            else:
                fields.append(
                    FieldSpec(
                        name=field_name,
                        alias=q_num,
                        python_type="Optional[List[str]]",
                        is_list=True,
                    )
                )

        elif q_type in ("multi-row", "mutli-row"):  # Handle typo in data
            options = data.get("options", [])
            enum_spec = self._get_or_create_enum(q_num, options)

            if enum_spec:
                fields.append(
                    FieldSpec(
                        name=field_name,
                        alias=q_num,
                        python_type=f"Optional[List[{enum_spec.name}]]",
                        enum_spec=enum_spec,
                        is_list=True,
                        description="Multi-row selection",
                    )
                )
            else:
                fields.append(
                    FieldSpec(
                        name=field_name,
                        alias=q_num,
                        python_type="Optional[List[str]]",
                        is_list=True,
                        description="Multi-row selection",
                    )
                )

        elif q_type == "multi_group":
            all_options = self._flatten_multi_group_options(data)
            enum_spec = self._get_or_create_enum(q_num, all_options)

            if enum_spec:
                fields.append(
                    FieldSpec(
                        name=field_name,
                        alias=q_num,
                        python_type=f"Optional[List[{enum_spec.name}]]",
                        enum_spec=enum_spec,
                        is_list=True,
                        description="Multi-group classification",
                    )
                )
            else:
                fields.append(
                    FieldSpec(
                        name=field_name,
                        alias=q_num,
                        python_type="Optional[List[str]]",
                        is_list=True,
                        description="Multi-group classification",
                    )
                )

        elif q_type == "grouped_single_select":
            options = self._flatten_grouped_options(data)
            enum_spec = self._get_or_create_enum(q_num, options)

            if enum_spec:
                fields.append(
                    FieldSpec(
                        name=field_name,
                        alias=q_num,
                        python_type=f"Optional[{enum_spec.name}]",
                        enum_spec=enum_spec,
                    )
                )
            else:
                fields.append(
                    FieldSpec(
                        name=field_name,
                        alias=q_num,
                        python_type="Optional[str]",
                    )
                )

        elif q_type == "grouped_multi_select":
            options = self._flatten_grouped_options(data)
            enum_spec = self._get_or_create_enum(q_num, options)

            if enum_spec:
                fields.append(
                    FieldSpec(
                        name=field_name,
                        alias=q_num,
                        python_type=f"Optional[List[{enum_spec.name}]]",
                        enum_spec=enum_spec,
                        is_list=True,
                    )
                )
            else:
                fields.append(
                    FieldSpec(
                        name=field_name,
                        alias=q_num,
                        python_type="Optional[List[str]]",
                        is_list=True,
                    )
                )

        elif q_type == "dynamic_select":
            fields.append(
                FieldSpec(
                    name=field_name,
                    alias=q_num,
                    python_type="Optional[str]",
                    description="Dynamic selection (runtime-determined)",
                )
            )

        else:
            # Unknown or text field - use str
            fields.append(
                FieldSpec(
                    name=field_name,
                    alias=q_num,
                    python_type="Optional[str]",
                )
            )

        return fields

    def _get_or_create_enum(
        self, q_num: str, options: List[str]
    ) -> Optional[EnumSpec]:
        """Create enum spec for options. Returns None if no options."""
        if not options:
            return None

        # Check if matches a fixed enum (use the fixed enum name)
        options_set = set(options)
        for enum_name, fixed_opts in self.FIXED_ENUMS.items():
            if options_set == set(fixed_opts) or options_set.issubset(set(fixed_opts)):
                # Create enum spec with the fixed name
                return EnumSpec(name=enum_name, values=list(options_set))

        # Create question-specific enum
        safe_name = q_num.replace(".", "_")
        enum_name = f"Q{safe_name}Options"

        return EnumSpec(name=enum_name, values=options)

    def _flatten_multi_group_options(self, data: Dict[str, Any]) -> List[str]:
        """Flatten multi_group options into single list."""
        all_options = []
        for group in data.get("groups", []):
            all_options.extend(group.get("options", []))
        return all_options

    def _flatten_grouped_options(self, data: Dict[str, Any]) -> List[str]:
        """Flatten grouped options into single list."""
        all_options = []
        groups = data.get("groups", {})

        if isinstance(groups, dict):
            for options in groups.values():
                if isinstance(options, list):
                    all_options.extend(options)
        elif isinstance(groups, list):
            for group in groups:
                if isinstance(group, dict):
                    all_options.extend(group.get("options", []))

        return all_options

    def _write_group_files(self) -> None:
        """Write group schema files with inline enums."""
        groups_dir = self.output_dir / "groups"
        groups_dir.mkdir(parents=True, exist_ok=True)

        for group_id, schema in self.group_schemas.items():
            file_name = f"group_{group_id.replace('.', '_')}.py"
            file_path = groups_dir / file_name

            content = self._generate_group_file_content(schema)
            file_path.write_text(content)

        print(f"Generated {len(self.group_schemas)} group schema files to {groups_dir}")

    def _generate_group_file_content(self, schema: GroupSchema) -> str:
        """Generate Python file content for a group schema with inline enums."""
        lines = [
            f'"""Schema for scoring group {schema.group_id}.',
            "",
            "Auto-generated by schema_generator.py - DO NOT EDIT MANUALLY",
            '"""',
            "",
            "from enum import Enum",
            "from typing import List, Literal, Optional",
            "",
            "from pydantic import BaseModel, Field",
            "",
        ]

        # Collect unique enums needed for this group
        enums_needed: Dict[str, EnumSpec] = {}
        for f in schema.fields:
            if f.enum_spec and f.enum_spec.name not in enums_needed:
                enums_needed[f.enum_spec.name] = f.enum_spec

        # Generate inline enums
        if enums_needed:
            lines.append("")
            lines.append("# Inline enums for this group")
            lines.append("")

            for enum_name, enum_spec in sorted(enums_needed.items()):
                lines.append(f"class {enum_name}(str, Enum):")
                lines.append(f'    """Options for {enum_name}."""')
                lines.append("")

                for py_name, value in enum_spec.python_values.items():
                    # Escape quotes in value
                    safe_value = value.replace("\\", "\\\\").replace('"', '\\"')
                    lines.append(f'    {py_name} = "{safe_value}"')

                lines.append("")

        # Generate class
        lines.append("")
        lines.append(f"class {schema.class_name}(BaseModel):")
        lines.append(f'    """Schema for scoring group {schema.group_id}."""')
        lines.append("")

        # Group ID field
        lines.append(f'    group_id: Literal["{schema.group_id}"] = Field(')
        lines.append(f'        default="{schema.group_id}",')
        lines.append('        description="Scoring group identifier"')
        lines.append("    )")

        # Question fields
        for f in schema.fields:
            desc = f.description or f"Answer for question {f.alias}"
            # Escape description for Python string
            desc = desc.replace("\\", "\\\\").replace('"', '\\"').replace("\n", " ")
            # Truncate very long descriptions
            if len(desc) > 200:
                desc = desc[:197] + "..."

            lines.append(f"    {f.name}: {f.python_type} = Field(")
            lines.append("        None,")
            lines.append(f'        alias="{f.alias}",')
            if f.max_length:
                lines.append(f"        max_length={f.max_length},")
            lines.append(f'        description="{desc}"')
            lines.append("    )")

        # Model config
        lines.append("")
        lines.append("    model_config = {")
        lines.append('        "populate_by_name": True,  # Allow both alias and field name')
        if schema.is_multi_row:
            lines.append('        "extra": "allow",  # Allow row-prefixed keys for multi-row groups')
        else:
            lines.append('        "extra": "forbid",  # Reject fields not in this group')
        lines.append("    }")
        
        # Generate static dependencies constant
        lines.append("")
        lines.append("")
        lines.append("# =============================================================================")
        lines.append("# Static Dependencies (generated at compile time)")
        lines.append("# =============================================================================")
        lines.append("")
        lines.append("GROUP_DEPENDENCIES = {")
        
        # Field dependencies
        lines.append('    "fields": [')
        for fd in schema.dependencies.fields:
            lines.append("        {")
            lines.append(f'            "question_number": "{fd.question_number}",')
            lines.append(f'            "source_group": "{fd.source_group}",')
            lines.append(f'            "reason": "{fd.reason}",')
            lines.append("        },")
        # Add row_source sibling dependencies (e.g., 3.5.2 depends on 3.5.1.1)
        for q in schema.questions:
            row_source = getattr(q, 'row_source', None)
            if row_source:
                dep_q = row_source.split(':contains=')[0].strip()
                dep_group = '.'.join(dep_q.split('.')[:-1])  # e.g., "3.5.1.1" -> "3.5.1"
                # Avoid duplicates
                existing = {(fd.question_number, fd.source_group) for fd in schema.dependencies.fields}
                if (dep_q, dep_group) not in existing:
                    lines.append("        {")
                    lines.append(f'            "question_number": "{dep_q}",')
                    lines.append(f'            "source_group": "{dep_group}",')
                    lines.append(f'            "reason": "row_source",')
                    lines.append("        },")
        lines.append("    ],")

        # Score dependencies
        lines.append('    "scores": [')
        for sd in schema.dependencies.scores:
            lines.append("        {")
            lines.append(f'            "group_id": "{sd.group_id}",')
            lines.append(f'            "category": "{sd.category}",')
            lines.append(f'            "requirement": "{sd.requirement}",')
            lines.append("        },")
        lines.append("    ],")
        lines.append("}")

        return "\n".join(lines) + "\n"

    def _update_groups_init(self) -> None:
        """Update groups __init__.py with all exports."""
        init_path = self.output_dir / "groups" / "__init__.py"

        lines = [
            '"""Generated group schemas for CDP scoring.',
            "",
            "Auto-generated by schema_generator.py - DO NOT EDIT MANUALLY",
            '"""',
            "",
        ]

        # Generate imports
        for group_id, schema in sorted(self.group_schemas.items()):
            module_name = f"group_{group_id.replace('.', '_')}"
            lines.append(f"from .{module_name} import {schema.class_name}")

        lines.append("")
        lines.append("__all__ = [")
        for schema in sorted(self.group_schemas.values(), key=lambda s: s.group_id):
            lines.append(f'    "{schema.class_name}",')
        lines.append("]")

        init_path.write_text("\n".join(lines) + "\n")

    def _update_schemas_init(self) -> None:
        """Update schemas __init__.py with GroupData discriminated union."""
        init_path = self.output_dir / "__init__.py"

        lines = [
            '"""',
            "CDP Scoring API Schemas",
            "",
            "This package contains Pydantic schemas for CDP scoring groups.",
            "Each scoring group has its own schema file with inline enums.",
            "",
            "The GroupData type is a discriminated union of all group schemas,",
            "allowing the /score endpoint to validate requests based on group_id.",
            "",
            "Auto-generated by schema_generator.py - DO NOT EDIT MANUALLY",
            '"""',
            "",
            "from typing import Annotated, Union",
            "",
            "from pydantic import Field",
            "",
            "from .base import (",
            "    CategoryScore,",
            "    ScoringResponse,",
            "    ErrorResponse,",
            "    FieldDependencyModel,",
            "    ScoreDependencyModel,",
            "    DependenciesModel,",
            "    SchemaWithDependenciesResponse,",
            "    DependencyScoresInput,",
            ")",
        ]

        # Import all group schemas
        sorted_schemas = sorted(self.group_schemas.values(), key=lambda s: s.group_id)

        lines.append("")
        lines.append("# Import all group schemas")
        lines.append("from .groups import (")
        for schema in sorted_schemas:
            lines.append(f"    {schema.class_name},")
        lines.append(")")

        # Generate GroupData union
        lines.append("")
        lines.append("# Discriminated union of all group schemas")
        lines.append("# Pydantic will use 'group_id' to determine which schema to validate against")

        if len(sorted_schemas) > 0:
            union_parts = ", ".join(s.class_name for s in sorted_schemas)
            lines.append(f"GroupData = Annotated[Union[{union_parts}], Field(discriminator='group_id')]")
        else:
            lines.append("GroupData = None  # No groups generated")

        # Export all
        lines.append("")
        lines.append("__all__ = [")
        lines.append('    "CategoryScore",')
        lines.append('    "ScoringResponse",')
        lines.append('    "ErrorResponse",')
        lines.append('    "FieldDependencyModel",')
        lines.append('    "ScoreDependencyModel",')
        lines.append('    "DependenciesModel",')
        lines.append('    "SchemaWithDependenciesResponse",')
        lines.append('    "DependencyScoresInput",')
        lines.append('    "GroupData",')
        for schema in sorted_schemas:
            lines.append(f'    "{schema.class_name}",')
        lines.append("]")

        init_path.write_text("\n".join(lines) + "\n")
        print(f"Updated {init_path} with GroupData union of {len(sorted_schemas)} schemas")


def main():
    """CLI entry point."""
    import argparse

    parser = argparse.ArgumentParser(description="Generate Pydantic schemas from JSON")
    parser.add_argument(
        "--classification-dir",
        default="classificationOptions",
        help="Directory containing classification JSON files",
    )
    parser.add_argument(
        "--conditional-dir",
        default="conditionalJSON",
        help="Directory containing conditional scoring JSON files",
    )
    parser.add_argument(
        "--output-dir",
        default="backend/api/schemas",
        help="Output directory for generated schemas",
    )
    parser.add_argument(
        "--spreadsheet",
        default="CDP_scoring_questions.xlsx",
        help="Spreadsheet with question metadata (for non-classification types)",
    )
    args = parser.parse_args()

    generator = SchemaGenerator(
        classification_dir=args.classification_dir,
        conditional_dir=args.conditional_dir,
        output_dir=args.output_dir,
        spreadsheet_path=args.spreadsheet,
    )

    result = generator.generate_all()
    print(f"\nGeneration complete:")
    print(f"  Groups: {result['groups']}")
    print(f"  Fields: {result['total_fields']}")


if __name__ == "__main__":
    main()
