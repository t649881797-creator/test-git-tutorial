"""
Compiler Configuration and Data Structures

Defines the data structures and mappings used by the compiler.
"""

from dataclasses import dataclass, field
from typing import Optional, List, Dict, Any


# Question type mappings from spreadsheet to ResponseType enum
QUESTION_TYPE_MAPPING = {
    "Date": "DATE",
    "classification": "SELECT_ONE",
    "Multi-group classification": "MULTIPLE_CHOICE",
    "text_field": "TEXT_FIELD",
    "numeric": "NUMERIC",
}

# Response type enum values
RESPONSE_TYPE_MAPPING = {
    "DATE": "DATE",
    "SELECT_ONE": "SELECT_ONE",
    "MULTIPLE_CHOICE": "MULTIPLE_CHOICE",
    "TEXT_FIELD": "TEXT_FIELD",
    "NUMERIC": "NUMERIC",
}


@dataclass
class QuestionSpec:
    """
    Specification for a single CDP question parsed from the spreadsheet.
    
    This represents one row from the Excel file with all necessary information
    to generate the question code.
    """
    # Core question info
    question_number: str
    question_text: str
    
    # Point allocations (4 categories)
    disclosure_max_points: float
    awareness_max_points: float
    management_max_points: float
    leadership_max_points: float
    
    # Points if answered (for completeness-based scoring)
    disclosure_points_if_answered: float
    awareness_points_if_answered: float
    management_points_if_answered: float
    leadership_points_if_answered: float
    
    # Question metadata
    dependencies: Optional[str] = None  # Parent question number
    question_type: str = "classification"  # Type from spreadsheet
    scoring_group: str = ""  # Scoring group identifier (e.g., "1.4")
    conditional_on: Optional[str] = None  # Condition string (e.g., "1.4.0.3=Yes")
    
    # Options and rules (parsed JSON)
    classification_options: Optional[Dict[str, Any]] = None  # Must have 'type' and 'question_type' fields
    conditional_scoring_rules: Optional[Dict[str, Any]] = None
    
    # Additional notes
    notes: Optional[str] = None

    # Row source: specifies which parent question's answers determine the rows
    # Format: "parent_question_num" or "parent_question_num:contains=keyword"
    # Example: "3.5.1.1:contains=ETS", "1.7.0.1"
    row_source: Optional[str] = None

    @property
    def needs_ai_scoring(self) -> bool:
        """
        Determine if this question needs AI scoring (LLM prompts).
        If max_points != points_if_answered, then AI evaluation is needed.
        """
        return (
            self.disclosure_max_points != self.disclosure_points_if_answered or
            self.awareness_max_points != self.awareness_points_if_answered or
            self.management_max_points != self.management_points_if_answered or
            self.leadership_max_points != self.leadership_points_if_answered
        )
    
    @property
    def response_type(self) -> str:
        """Get the ResponseType enum value for this question."""
        return QUESTION_TYPE_MAPPING.get(self.question_type, "TEXT_FIELD")
    
    @property
    def filename(self) -> str:
        """Get the filename for this question (e.g., question_1_4_0_1.py)."""
        # Ensure question_number is a string and replace dots with underscores
        sanitized = str(self.question_number).replace(".", "_")
        return f"question_{sanitized}.py"
    
    @property
    def function_name(self) -> str:
        """Get the function name for this question (e.g., get_question_1_4_0_1)."""
        # Ensure question_number is a string and replace dots with underscores
        sanitized = str(self.question_number).replace(".", "_")
        return f"get_question_{sanitized}"
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for debugging."""
        return {
            "question_number": self.question_number,
            "question_text": self.question_text,
            "question_type": self.question_type,
            "response_type": self.response_type,
            "scoring_group": self.scoring_group,
            "needs_ai_scoring": self.needs_ai_scoring,
            "dependencies": self.dependencies,
            "conditional_on": self.conditional_on,
        }

