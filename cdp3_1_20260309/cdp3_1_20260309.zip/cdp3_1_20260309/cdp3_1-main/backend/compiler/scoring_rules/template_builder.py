"""
Template Builder

Main coordinator for generating scoring function templates.
Delegates to specialized generators for different aspects of code generation.

This module serves as the entry point for building complete scoring files.
The actual generation logic is distributed across the generators/ package.
"""

from typing import List, Dict, Any, Optional
from ..compiler_config import QuestionSpec
from .helpers import ScoringHelpers
from .base import RuleContext
from .condition_parser import ConditionParser
from .rules import generate_rule

# Import generators
from .generators import (
    FileStructureGenerator,
    AIIntegrationGenerator,
    GroupScoringGenerator,
    RowScoringGenerator,
    FixedRowsMainGenerator,
)


class TemplateBuilder:
    """
    Builds complete scoring function templates with imports and structure.
    
    This class coordinates the various generators to produce complete
    scoring function files. It maintains backward compatibility with
    the original interface while delegating to specialized generators.
    """
    
    def __init__(self, ai_generators, questions_by_number: Dict[str, QuestionSpec],
                 condition_parser: Optional[ConditionParser] = None,
                 strict_mode: bool = True):
        """
        Initialize the template builder.
        
        Args:
            ai_generators: AIGenerators instance for AI helper function generation
            questions_by_number: Dictionary mapping question numbers to QuestionSpec objects
            condition_parser: ConditionParser instance (optional, will be created if not provided)
            strict_mode: If True, raise exceptions for unknown rule types instead of writing error comments
        """
        self.ai_generators = ai_generators
        self.questions_by_number = questions_by_number
        self.helpers = ScoringHelpers
        self.strict_mode = strict_mode
        
        # Initialize condition parser if not provided
        self.condition_parser = condition_parser or ConditionParser(questions_by_number)
        
        # Create RuleContext for new rule system
        self._rule_context = RuleContext(
            questions_by_number=questions_by_number,
            condition_parser=self.condition_parser,
            use_row_answers=False,
            current_scoring_group=None
        )
        
        # Initialize generators
        self._init_generators()
    
    def _init_generators(self):
        """Initialize the specialized generators."""
        self.group_scoring_gen = GroupScoringGenerator(
            rule_generator=self._generate_rule_code,
            context_factory=self._get_rule_context,
            strict_mode=self.strict_mode
        )
        
        self.row_scoring_gen = RowScoringGenerator(
            rule_generator=self._generate_rule_code,
            context_factory=self._get_rule_context,
            strict_mode=self.strict_mode
        )
        
        self.multi_row_gen = FixedRowsMainGenerator(
            rule_generator=self._generate_rule_code,
            context_factory=self._get_rule_context,
            questions_by_number=self.questions_by_number,
            strict_mode=self.strict_mode
        )
    
    def _get_rule_context(self, use_row_answers: bool = False, scoring_group: str = None) -> RuleContext:
        """Get a RuleContext configured for the current context."""
        return RuleContext(
            questions_by_number=self.questions_by_number,
            condition_parser=self.condition_parser,
            use_row_answers=use_row_answers,
            current_scoring_group=scoring_group
        )
    
    def _generate_rule_code(self, rule: Dict[str, Any], category: str, max_points: float,
                           question: QuestionSpec, use_row_answers: bool = False) -> List[str]:
        """
        Generate code for a rule using the modular rule router.
        """
        ctx = self._get_rule_context(
            use_row_answers=use_row_answers,
            scoring_group=question.scoring_group if question else None
        )
        
        return generate_rule(
            rule=rule,
            var_name=f"{category}_score",
            category=category,
            max_points=max_points,
            question=question,
            ctx=ctx
        )
    
    def build_scoring_file(self, scoring_group: str, questions: List[QuestionSpec], 
                          needs_ai: bool) -> str:
        """
        Build complete scoring function file content.
        
        Args:
            scoring_group: Scoring group identifier (e.g., "3.1.1")
            questions: List of questions in the group
            needs_ai: Whether AI scoring is needed
        
        Returns:
            Complete Python file content as string
        """
        # Detect whether the multi-row counting helpers are needed
        needs_helpers = any(
            q.question_type and q.question_type == "multi-row" for q in questions
        )
        
        # Build imports
        imports = FileStructureGenerator.build_imports(
            needs_ai,
            needs_helpers=needs_helpers,
            needs_ai_helpers=needs_ai,
        )
        
        # Build main scoring function
        main_function = self._build_main_function(scoring_group, questions)
        
        # Build get_max_scores helper function
        max_scores_function = FileStructureGenerator.build_max_scores_function(scoring_group, questions)
        
        # Build AI helper functions if needed
        ai_helpers = ""
        if needs_ai:
            ai_points_map = AIIntegrationGenerator.get_ai_points_needed(questions)
            ai_helpers = "\n\n" + self.ai_generators.generate_ai_helper_functions(
                scoring_group, questions, ai_points_map
            )
        
        # Build module-level row_source dependency constant (for API consumers)
        row_source_constant = ""
        for q in questions:
            if q.row_source:
                # Extract the parent question number (before optional :contains=...)
                dep_q = q.row_source.split(':contains=')[0].strip()
                row_source_constant = (
                    f"\n# Sibling question required for row_source penalty scoring.\n"
                    f"# Include this question's answer in the API payload when scoring {scoring_group}.\n"
                    f"ROW_SOURCE_DEP_QUESTION = {repr(dep_q)}\n"
                )
                break  # Only one grouping question per group

        # Combine all parts
        return f"{imports}{row_source_constant}\n\n{main_function}\n\n{max_scores_function}{ai_helpers}"
    
    # =========================================================================
    # Backward Compatibility - Delegate Methods
    # =========================================================================
    
    def _build_imports(self, needs_ai: bool, needs_helpers: bool = False, needs_ai_helpers: bool = False) -> str:
        """Generate import statements for the scoring file."""
        return FileStructureGenerator.build_imports(needs_ai, needs_helpers=needs_helpers, needs_ai_helpers=needs_ai_helpers)
    
    def _build_main_function(self, scoring_group: str, questions: List[QuestionSpec]) -> str:
        """Build the main scoring function."""
        # Check if we need sector-based routing
        reference_question = questions[0] if questions else None
        conditional_rules = reference_question.conditional_scoring_rules if reference_question else None
        
        if conditional_rules:
            # Check if there are multiple sector blocks
            from .sector_resolver import get_all_sector_blocks
            sector_blocks = get_all_sector_blocks(conditional_rules)
            
            if len(sector_blocks) > 1 or (len(sector_blocks) == 1 and sector_blocks[0].get("sectors", [])):
                # Multiple sector blocks or at least one sector-specific block
                # Generate routing code and separate methods
                return self._build_sector_routed_function(scoring_group, questions)
            elif len(sector_blocks) == 1:
                # Only default block - extract rules dict and use single method
                default_rules = sector_blocks[0].get("rules")
                if default_rules:
                    # Temporarily set rules dict on questions
                    original_rules = []
                    for q in questions:
                        original_rules.append(q.conditional_scoring_rules)
                        q.conditional_scoring_rules = default_rules
                    try:
                        signature = FileStructureGenerator.build_function_signature(scoring_group, questions)
                        body = self._build_function_body(scoring_group, questions)
                        return f"{signature}\n{body}"
                    finally:
                        # Restore original rules
                        for q, orig_rules in zip(questions, original_rules):
                            q.conditional_scoring_rules = orig_rules
        
        # Single method (no sector routing needed, no conditional rules)
        signature = FileStructureGenerator.build_function_signature(scoring_group, questions)
        body = self._build_function_body(scoring_group, questions)
        return f"{signature}\n{body}"
    
    def _build_sector_routed_function(self, scoring_group: str, questions: List[QuestionSpec]) -> str:
        """Build main function with sector routing and separate sector methods."""
        from .sector_resolver import get_all_sector_blocks
        
        reference_question = questions[0]
        conditional_rules = reference_question.conditional_scoring_rules
        
        # Determine if AI is needed (before building routing so we can pass it)
        needs_ai = any(
            getattr(q, f'{cat}_max_points', 0) > getattr(q, f'{cat}_points_if_answered', 0)
            for q in questions
            for cat in ['disclosure', 'awareness', 'management', 'leadership']
        )
        
        # Get routing structure (pass needs_ai so routing code conditionally includes gemini_client)
        routing_info = FileStructureGenerator.build_sector_routing(scoring_group, conditional_rules, needs_ai)
        routing_lines = routing_info["routing_lines"]
        sector_blocks = routing_info["sector_blocks"]
        
        if not sector_blocks:
            # Fallback to single method
            signature = FileStructureGenerator.build_function_signature(scoring_group, questions)
            body = self._build_function_body(scoring_group, questions)
            return f"{signature}\n{body}"
        
        # Build main function with routing
        main_signature = FileStructureGenerator.build_function_signature(scoring_group, questions)
        main_body = "\n".join(routing_lines)
        main_function = f"{main_signature}\n{main_body}"
        
        # Build separate methods for each sector block
        sector_methods = []
        for sector_info in sector_blocks:
            sector_code = sector_info["sector_code"]
            rules = sector_info["rules"]
            method_name = sector_info["method_name"]
            
            # Temporarily override conditional_scoring_rules for all questions
            original_rules = []
            for q in questions:
                original_rules.append(q.conditional_scoring_rules)
                q.conditional_scoring_rules = rules  # Temporarily set to this sector's rules
            
            try:
                # Build method signature
                method_signature = FileStructureGenerator.build_sector_method_signature(
                    method_name, sector_code, needs_ai
                )
                
                # Build method body (same structure as main function, but with embedded rules)
                method_body = self._build_function_body(scoring_group, questions)
                
                sector_methods.append(f"{method_signature}\n{method_body}")
            finally:
                # Restore original rules
                for q, orig_rules in zip(questions, original_rules):
                    q.conditional_scoring_rules = orig_rules
        
        # Combine main function and all sector methods
        all_functions = [main_function] + sector_methods
        return "\n\n".join(all_functions)
    
    def _build_function_signature(self, scoring_group: str, 
                                  questions: List[QuestionSpec]) -> str:
        """Build the function signature with docstring."""
        return FileStructureGenerator.build_function_signature(scoring_group, questions)
    
    def _build_function_body(self, scoring_group: str, questions: List[QuestionSpec]) -> str:
        """Build the function body with scoring logic."""
        lines = []
        
        # Check if this is a multi-row question (returns early with different structure)
        is_multi_row = any(q.question_type and q.question_type == "multi-row" for q in questions)
        
        if is_multi_row:
            # Multi-row questions: the scoring logic handles everything including return
            # No need for score variable initialization - it's done per-group
            scoring_logic = self._build_scoring_logic(questions)
            lines.extend(scoring_logic)
            return "\n".join(lines)
        
        # Initialize score variables (for non-multi-row questions)
        lines.extend(FileStructureGenerator.build_score_initialization())
        
        # Generate scoring logic based on question structure
        scoring_logic = self._build_scoring_logic(questions)
        lines.extend(scoring_logic)
        
        # Add AI quality evaluation if applicable
        # NOTE: For group-level scoring with conditional rules, AI is already added inline
        # after each category (so prerequisite checks see full scores). Only add here for
        # other scoring types (row-based, completion, per-question).
        from ..spreadsheet_parser import SpreadsheetParser
        is_row_based_for_ai = SpreadsheetParser.is_row_based_scoring_group(questions)
        # Use the same check as _build_scoring_logic to determine if group-level conditional scoring is used
        # This ensures we don't add duplicate return statements
        has_identical_rules = self.helpers.check_identical_rules(questions)
        uses_group_level_conditional = has_identical_rules and questions[0].conditional_scoring_rules if questions else False
        
        if not uses_group_level_conditional:
            # AI not added inline, add at end
            ai_eval_calls = AIIntegrationGenerator.build_ai_evaluation_calls(questions)
            if ai_eval_calls:
                lines.extend(ai_eval_calls)
        
        # Return scores (with row-level breakdown if row-based)
        # NOTE: For group-level conditional scoring, return is already included in build_group_level_scoring()
        # Only add return here for other scoring types (row-based, per-question, default proportional)
        if not uses_group_level_conditional:
            is_row_based = SpreadsheetParser.is_row_based_scoring_group(questions)
            lines.extend(FileStructureGenerator.build_return_statement(is_row_based))
        
        return "\n".join(lines)
    
    def _build_ai_evaluation_calls(self, questions: List[QuestionSpec], 
                                   category_filter: str = None, 
                                   base_indent: str = "    ") -> List[str]:
        """Build AI evaluation calls for categories that need quality scoring."""
        return AIIntegrationGenerator.build_ai_evaluation_calls(
            questions, category_filter, base_indent
        )
    
    def _build_scoring_logic(self, questions: List[QuestionSpec]) -> List[str]:
        """
        Build the scoring logic for all questions.
        
        Determines whether to use group-level or per-question scoring based on
        whether questions have identical rules.
        """
        lines = []
        
        # Import SpreadsheetParser for row-based detection
        from ..spreadsheet_parser import SpreadsheetParser
        
        # Check if this is a row-based scoring group
        is_row_based = SpreadsheetParser.is_row_based_scoring_group(questions)
        
        if is_row_based:
            # Row-based (table) structure: extract rows and score each separately
            lines.append("    # Row-based (table) scoring - extract rows and score each separately")
            lines.extend(self._build_row_based_scoring(questions))
        else:
            # Check if all questions have identical scoring
            has_identical_rules = self.helpers.check_identical_rules(questions)
            has_identical_points = self.helpers.check_identical_points_if_answered(questions)
            
            if has_identical_rules and questions[0].conditional_scoring_rules:
                # All questions have identical conditional rules: evaluate once for the group
                # NOTE: build_group_level_scoring() includes return statements, so don't add another
                lines.append("    # Group-level scoring (all questions have identical rules)")
                lines.extend(self.group_scoring_gen.build_group_level_scoring(questions))
                # Return is already included in build_group_level_scoring() output
            elif has_identical_points and not any(q.conditional_scoring_rules for q in questions):
                # All questions have identical points_if_answered and no conditional rules
                # Default to proportional_cell_scoring (proportional based on answered questions)
                lines.append("    # Default proportional_cell_scoring (no scoring rules defined)")
                lines.extend(self._build_default_proportional_scoring(questions))
            else:
                # Questions have different rules or points: evaluate per question
                lines.append("    # Per-question scoring (questions have different rules)")
                lines.extend(self.group_scoring_gen.build_per_question_scoring(questions))
        
        return lines
    
    def _build_default_proportional_scoring(self, questions: List[QuestionSpec]) -> List[str]:
        """
        Generate default proportional_cell_scoring when no scoring rules are defined.
        
        This is the default behavior: award points proportionally based on how many
        visible questions are answered out of the total visible questions in the group.
        """
        lines = []
        if not questions:
            return lines
        
        reference_question = questions[0]
        
        # Check if disclosure has points
        has_disclosure = (reference_question.disclosure_points_if_answered or 0) > 0
        has_awareness = (reference_question.awareness_points_if_answered or 0) > 0
        has_management = (reference_question.management_points_if_answered or 0) > 0
        has_leadership = (reference_question.leadership_points_if_answered or 0) > 0
        
        if not (has_disclosure or has_awareness or has_management or has_leadership):
            lines.append("    # No completion points defined for this group")
            return lines
        
        # Create a synthetic proportional_cell_scoring rule
        from .rules import proportional_cell_scoring
        
        # Build context for rule generation
        ctx = self._get_rule_context(
            use_row_answers=False,
            scoring_group=reference_question.scoring_group
        )
        
        # Generate proportional scoring for each category that has points
        # The proportional_cell_scoring generator will correctly count only visible questions
        if has_disclosure:
            points = reference_question.disclosure_points_if_answered
            max_points = reference_question.disclosure_max_points or points
            synthetic_rule = {
                "type": "proportional_cell_scoring",
                "points": points
            }
            rule_code = proportional_cell_scoring.generate(
                synthetic_rule, "disclosure_score", "disclosure", max_points, reference_question, ctx
            )
            if rule_code:
                lines.extend([f"    {line}" for line in rule_code])
        
        if has_awareness:
            points = reference_question.awareness_points_if_answered
            max_points = reference_question.awareness_max_points or points
            synthetic_rule = {
                "type": "proportional_cell_scoring",
                "points": points
            }
            rule_code = proportional_cell_scoring.generate(
                synthetic_rule, "awareness_score", "awareness", max_points, reference_question, ctx
            )
            if rule_code:
                lines.extend([f"    {line}" for line in rule_code])
        
        if has_management:
            points = reference_question.management_points_if_answered
            max_points = reference_question.management_max_points or points
            synthetic_rule = {
                "type": "proportional_cell_scoring",
                "points": points
            }
            rule_code = proportional_cell_scoring.generate(
                synthetic_rule, "management_score", "management", max_points, reference_question, ctx
            )
            if rule_code:
                lines.extend([f"    {line}" for line in rule_code])
        
        if has_leadership:
            points = reference_question.leadership_points_if_answered
            max_points = reference_question.leadership_max_points or points
            synthetic_rule = {
                "type": "proportional_cell_scoring",
                "points": points
            }
            rule_code = proportional_cell_scoring.generate(
                synthetic_rule, "leadership_score", "leadership", max_points, reference_question, ctx
            )
            if rule_code:
                lines.extend([f"    {line}" for line in rule_code])
        
        return lines
    
    def _build_group_level_completion_scoring(self, questions: List[QuestionSpec]) -> List[str]:
        """Generate group-level completion-based scoring (simple check if any answered)."""
        return self.group_scoring_gen.build_group_level_completion_scoring(questions)
    
    def _build_group_level_scoring(self, questions: List[QuestionSpec]) -> List[str]:
        """Generate group-level conditional scoring (evaluate rules once for group)."""
        return self.group_scoring_gen.build_group_level_scoring(questions)
    
    def _build_row_based_scoring(self, questions: List[QuestionSpec]) -> List[str]:
        """
        Generate row-based (table) scoring logic.
        
        For "multi-row" questions (like 2.2.2 with Climate Change, Water, etc.):
        - Groups rows by the value of the grouping column (the question with type "multi-row")
        - Each group is scored independently and returns its own score object
        """
        lines = []
        
        if not questions:
            return lines
        
        # Find the grouping column (question with "multi-row" type)
        grouping_question = None
        for q in questions:
            if q.question_type and q.question_type == "multi-row":
                grouping_question = q
                break
        
        # If we have a grouping column, use multi-row scoring
        if grouping_question:
            return self.multi_row_gen.build_multi_row_scoring(questions, grouping_question)
        
        # Otherwise, use simple row-based scoring (legacy behavior)
        return self.row_scoring_gen.build_simple_row_based_scoring(questions)
    
    def _build_simple_row_based_scoring(self, questions: List[QuestionSpec]) -> List[str]:
        """
        Legacy row-based scoring - scores each row independently without grouping.
        Used when there's no "multi-row" question type.
        """
        return self.row_scoring_gen.build_simple_row_based_scoring(questions)
    
    def _build_multi_row_scoring(self, questions: List[QuestionSpec], 
                                  grouping_question: 'QuestionSpec') -> List[str]:
        """Generate scoring logic for "multi-row" questions."""
        return self.multi_row_gen.build_multi_row_scoring(questions, grouping_question)
    
    def _build_per_question_scoring(self, questions: List[QuestionSpec]) -> List[str]:
        """Generate per-question scoring logic."""
        return self.group_scoring_gen.build_per_question_scoring(questions)
    
    def _build_max_scores_function(self, scoring_group: str, questions: List[QuestionSpec]) -> str:
        """Build the get_max_scores helper function."""
        return FileStructureGenerator.build_max_scores_function(scoring_group, questions)
    
    def _get_ai_points_needed(self, questions: List[QuestionSpec]) -> Dict[str, float]:
        """Determine which categories need AI scoring and how many points."""
        return AIIntegrationGenerator.get_ai_points_needed(questions)
