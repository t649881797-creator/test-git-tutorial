"""
Fixed Rows Main Generator

Entry point for generating multi-rows scoring logic.
multi-rows questions group rows by a specific column value (e.g., "Climate change", "Water")
and score each group independently.
"""

from typing import List, Dict, Any, Callable, TYPE_CHECKING

if TYPE_CHECKING:
    from ....compiler_config import QuestionSpec
    from ...base import RuleContext

from .disclosure import FixedRowsDisclosureGenerator
from .categories import FixedRowsCategoryGenerator
from .global_scope import GlobalScopeGenerator


class FixedRowsMainGenerator:
    """Main generator for multi-rows scoring logic."""
    
    def __init__(
        self,
        rule_generator: Callable,
        context_factory: Callable,
        questions_by_number: Dict[str, 'QuestionSpec'],
        strict_mode: bool = True
    ):
        """
        Initialize the multi-rows scoring generator.
        
        Args:
            rule_generator: Function to generate code for individual rules
            context_factory: Function to create RuleContext instances
            questions_by_number: Dictionary mapping question numbers to QuestionSpec
            strict_mode: If True, raise exceptions for unknown rule types
        """
        self.rule_generator = rule_generator
        self.context_factory = context_factory
        self.questions_by_number = questions_by_number
        self.strict_mode = strict_mode
        
        # Get condition_parser from context_factory (via RuleContext)
        # Create a temporary context to access condition_parser
        temp_ctx = context_factory(use_row_answers=False, scoring_group=None)
        condition_parser = temp_ctx.condition_parser if hasattr(temp_ctx, 'condition_parser') else None
        
        # Initialize sub-generators
        self.disclosure_gen = FixedRowsDisclosureGenerator(condition_parser=condition_parser)
        self.category_gen = FixedRowsCategoryGenerator(
            rule_generator=rule_generator,
            context_factory=context_factory,
            strict_mode=strict_mode
        )
        self.global_scope_gen = GlobalScopeGenerator()
    
    def build_multi_row_scoring(
        self,
        questions: List['QuestionSpec'],
        grouping_question: 'QuestionSpec'
    ) -> List[str]:
        """
        Generate scoring logic for "multi-rows" questions.
        
        Two modes based on classification_options.question_type:
        
        1. "multi-row" (default): 
           - Disclosure is averaged across groups
           - Awareness/Management/Leadership scored once using all rows
           
        2. "multi-answer" or "environmental_issue_selector":
           - Each group gets its own complete score for all categories
           - Returns per-group scores dictionary
        
        Args:
            questions: All questions in the scoring group
            grouping_question: The question with "multi-rows" type that determines grouping
        
        Returns:
            List of Python code lines
        """
        lines = []
        
        scoring_group = questions[0].scoring_group
        grouping_q_num = grouping_question.question_number
        
        # Validate classification_options
        self._validate_classification_options(grouping_question)
        
        # Check classification_options to determine scoring mode
        is_multi_answer = self._is_multi_answer_mode(grouping_question)
        
        # Generate header and helper functions
        lines.extend(self._build_header_and_helpers())
        
        # Generate row extraction code
        lines.extend(self._build_row_extraction(scoring_group, grouping_q_num))
        
        # Generate grouping code
        lines.extend(self._build_row_grouping(grouping_q_num, scoring_group))
        
        # Generate scoring based on mode
        if is_multi_answer:
            # Per-group scoring - each group gets its own complete score
            lines.extend(self._build_per_group_scoring_loop(questions, grouping_question))
        else:
            # Default: average disclosure + single awareness/management/leadership
            lines.extend(self._build_group_scoring_loop(questions, grouping_question))
        
        return lines
    
    def _validate_classification_options(self, grouping_question: 'QuestionSpec') -> None:
        """
        Validate that classification_options is properly configured.
        
        Raises:
            ValueError: If classification_options is missing or invalid
        """
        class_opts = grouping_question.classification_options
        q_num = grouping_question.question_number
        sg = grouping_question.scoring_group
        
        if not class_opts:
            raise ValueError(
                f"COMPILER ERROR: Scoring group {sg}, question {q_num} "
                f"has question_type='multi-row' but classification_options is empty. "
                f"Please update the spreadsheet with valid JSON containing 'type' and 'question_type' fields."
            )
        
        if not isinstance(class_opts, dict):
            raise ValueError(
                f"COMPILER ERROR: Scoring group {sg}, question {q_num} "
                f"has invalid classification_options (not a dict). "
                f"Please update the spreadsheet with valid JSON."
            )
        
        if "type" not in class_opts:
            raise ValueError(
                f"COMPILER ERROR: Scoring group {sg}, question {q_num} "
                f"classification_options is missing 'type' field. "
                f"Please update the spreadsheet."
            )
        
        if "question_type" not in class_opts:
            raise ValueError(
                f"COMPILER ERROR: Scoring group {sg}, question {q_num} "
                f"classification_options is missing 'question_type' field. "
                f"Valid values: 'multi-row' (default), 'multi-answer', 'environmental_issue_selector'. "
                f"Please update the spreadsheet."
            )
    
    def _is_multi_answer_mode(self, grouping_question: 'QuestionSpec') -> bool:
        """
        Check if this is a multi-answer multi-rows question.
        
        Multi-answer mode (per-group scoring) is used when:
        - classification_options.question_type is "multi-answer"
        
        Default mode (averaged disclosure, single awareness/management) is used when:
        - classification_options.question_type is "multi-row"
        """
        class_opts = grouping_question.classification_options
        # Already validated in _validate_classification_options
        inner_type = class_opts.get("question_type", "multi-row")
        return inner_type in ("multi-answer")
    
    def _build_header_and_helpers(self) -> List[str]:
        """Build header comment. Counting helpers are imported from scoring_helpers."""
        lines = []
        lines.append("    # multi-rows scoring: group by environmental issue and score each independently")
        lines.append("    ")
        lines.append("    # Track AI explanations for each group")
        lines.append("    ai_explanations = {}")
        lines.append("    ")
        return lines
    
    def _build_row_extraction(self, scoring_group: str, grouping_q_num: str) -> List[str]:
        """Build row extraction code."""
        lines = []
        
        lines.append("    # Extract rows from answers")
        lines.append("    # Format: {scoring_group}.Row {row_num}.{question_num}")
        lines.append("    # Example: 3.6.1.Row 1.3.6.1.1 = Row 1, Question 3.6.1.1")
        lines.append("    # The grouping question (e.g., 3.6.1.1) contains the group name (e.g., 'Climate change')")
        lines.append("    rows = {}")
        lines.append("    for key in answers.keys():")
        lines.append(f'        if key.startswith("{scoring_group}.Row "):')
        lines.append(f'            prefix_to_remove = "{scoring_group}.Row "')
        lines.append('            remainder = key[len(prefix_to_remove):]')
        lines.append('            parts = remainder.split(".")')
        lines.append('            if len(parts) < 2:')
        lines.append('                continue')
        lines.append('            row_id = f"Row {parts[0]}"  # e.g., "Row 1", "Row 2"')
        lines.append('            # Extract question number (everything after row identifier)')
        lines.append('            q_suffix = ".".join(parts[1:])')
        lines.append(f'            if not q_suffix.startswith("{scoring_group}."):')
        lines.append(f'                raise ValueError(f"Invalid answer key format: {{key}}. Expected: {scoring_group}.Row <num>.{scoring_group}.<question>")')
        lines.append('            question_num = q_suffix')
        lines.append('            if row_id not in rows:')
        lines.append('                rows[row_id] = {}')
        lines.append('            rows[row_id][question_num] = answers[key]')
        lines.append("    ")
        lines.append("    if not rows:")
        lines.append("        # Return zero scores with empty tracking when no rows submitted")
        lines.append("        from collections import defaultdict")
        lines.append("        return ({'disclosure': 0.0, 'awareness': 0.0, 'management': 0.0, 'leadership': 0.0}, defaultdict(list))")
        lines.append("    ")
        
        return lines
    
    def _build_row_grouping(self, grouping_q_num: str, scoring_group: str = None) -> List[str]:
        """Build code to group rows by the grouping question value.
        
        If the grouping question value is not found in the row, attempts to find it
        from a parent scoring group by matching row numbers.
        """
        lines = []
        
        # Check if this is a child group (e.g., 5.1.1 is child of 5.1)
        parent_group = None
        parent_grouping_q = None
        if scoring_group and '.' in scoring_group:
            # Try to find parent group (e.g., 5.1 from 5.1.1)
            parts = scoring_group.split('.')
            if len(parts) >= 2:
                # Try parent groups: 5.1.1 -> 5.1, 3.6.2 -> 3.6
                for i in range(len(parts) - 1, 0, -1):
                    potential_parent = '.'.join(parts[:i])
                    # Parent grouping question would be like 5.1.0.0 for group 5.1
                    # Format: {parent_group}.0.0
                    potential_parent_q = f"{potential_parent}.0.0"
                    parent_group = potential_parent
                    parent_grouping_q = potential_parent_q
                    break
        
        lines.append(f'    # Group rows by the value of {grouping_q_num} (environmental issue)')
        if parent_group and parent_grouping_q:
            lines.append(f'    # Note: If {grouping_q_num} is missing, will try parent group {parent_group}\'s {parent_grouping_q}')
        lines.append("    groups = {}")
        lines.append("    for row_id, row_answers in rows.items():")
        lines.append(f'        group_value = row_answers.get("{grouping_q_num}")')
        
        # If grouping value not found and we have a parent, try parent's grouping question
        if parent_group and parent_grouping_q:
            lines.append("        ")
            lines.append("        # If grouping value not found, try parent group's grouping question")
            lines.append("        if not group_value:")
            lines.append(f"            # Extract row number (e.g., 'Row 1' -> '1')")
            lines.append("            row_num = row_id.replace('Row ', '')")
            lines.append(f"            # Look up parent grouping question in same row")
            lines.append(f"            parent_key = f'{parent_group}.{{row_id}}.{parent_grouping_q}'")
            lines.append("            group_value = answers.get(parent_key)")
            lines.append("            ")
            lines.append("            # If still not found, try to find any parent grouping question with matching row")
            lines.append("            if not group_value:")
            lines.append("                for key, value in answers.items():")
            lines.append(f"                    if key.startswith(f'{parent_group}.{{row_id}}') and key.endswith('{parent_grouping_q}'):")
            lines.append("                        group_value = value")
            lines.append("                        break")
            lines.append("        ")
        
        lines.append("        if group_value:")
        lines.append("            # Handle list values (multi-select)")
        lines.append("            if isinstance(group_value, list):")
        lines.append("                for val in group_value:")
        lines.append("                    if val not in groups:")
        lines.append("                        groups[val] = []")
        lines.append("                    groups[val].append(row_answers)")
        lines.append("            else:")
        lines.append("                if group_value not in groups:")
        lines.append("                    groups[group_value] = []")
        lines.append("                groups[group_value].append(row_answers)")
        lines.append("        else:")
        lines.append("            # If we can't find the grouping value, use row number as fallback")
        lines.append("            row_num = row_id.replace('Row ', '')")
        lines.append("            fallback_group = f'Row {row_num}'")
        lines.append("            if fallback_group not in groups:")
        lines.append("                groups[fallback_group] = []")
        lines.append("            groups[fallback_group].append(row_answers)")
        lines.append("    ")
        
        return lines

    def _build_row_source_penalty(self, row_source: str, max_disclosure_pts: float = 0.0) -> List[str]:
        """
        Generate code that adds zero-scored entries for expected-but-missing rows,
        computes _rs_actual_ratio for category scaling, and adds tracking entries.

        row_source format:
            "parent_q_num"                  -> all answers from parent question count
            "parent_q_num:contains=keyword" -> only answers containing keyword count
        """
        lines = []

        # Parse row_source at compile time
        if ':contains=' in row_source:
            parent_q_num, rest = row_source.split(':contains=', 1)
            keyword = rest.strip().lower()
            filter_expr = f"[str(v) for v in _rs_raw if {repr(keyword)} in str(v).lower()]"
        else:
            parent_q_num = row_source.strip()
            keyword = None
            filter_expr = "[str(v) for v in _rs_raw]"

        lines.append(f"    # row_source penalty: expected rows from {parent_q_num}, missing rows score 0")
        lines.append(f"    _rs_answer = answers.get({repr(parent_q_num)})")
        lines.append("    if _rs_answer is None:")
        lines.append("        _rs_raw = []")
        lines.append("    elif isinstance(_rs_answer, list):")
        lines.append("        _rs_raw = _rs_answer")
        lines.append("    else:")
        lines.append("        _rs_raw = [_rs_answer]")
        lines.append(f"    _rs_expected = {filter_expr}")
        lines.append("    _rs_missing = max(0, len(_rs_expected) - len(groups))")
        # Ratio used later to scale awareness/management/leadership
        lines.append("    _rs_actual_ratio = min(1.0, len(groups) / max(1, len(_rs_expected))) if _rs_expected else 1.0")
        # Append zeros for missing rows + tracking entries for Fix 3
        lines.append("    if _rs_missing > 0:")
        lines.append("        _rs_avg_visible = (")
        lines.append("            sum(t.get('total_rows', 0) for t in _group_disclosure_tracking)")
        lines.append("            / max(1, len(groups))")
        lines.append("        )")
        lines.append("        for _mi in range(_rs_missing):")
        lines.append("            group_disclosure_scores.append(0.0)")
        lines.append("            _group_disclosure_tracking.append({")
        lines.append("                'rule_type': 'proportional_row_scoring',")
        lines.append("                'rule_description': 'Expected row not submitted (row_source penalty)',")
        lines.append("                'completed_rows': 0,")
        lines.append("                'total_rows': round(_rs_avg_visible),")
        lines.append("                'percentage': 0.0,")
        lines.append("                'points_awarded': 0.0,")
        lines.append(f"                'max_points': {max_disclosure_pts},")
        lines.append("                'reason': 'Row expected from parent question but not submitted',")
        lines.append("                'group_name': f'missing_row_{_mi + 1}'")
        lines.append("            })")
        lines.append("    ")

        return lines

    def _build_row_source_category_scaling(self) -> List[str]:
        """
        Generate code to scale awareness/management/leadership by _rs_actual_ratio.

        Called after the category scoring block when row_source is present.
        _rs_actual_ratio is set by _build_row_source_penalty() earlier in the function.
        """
        lines = []
        lines.append("    # Scale awareness/management/leadership by actual/expected row ratio")
        lines.append("    group_awareness = group_awareness * _rs_actual_ratio")
        lines.append("    group_management = group_management * _rs_actual_ratio")
        lines.append("    group_leadership = group_leadership * _rs_actual_ratio")
        lines.append("    ")
        return lines

    def _build_group_scoring_loop(
        self,
        questions: List['QuestionSpec'],
        grouping_question: 'QuestionSpec'
    ) -> List[str]:
        """Build the main scoring loop for each group.
        
        Default behavior for multi-rows questions:
        - Disclosure: Score per-group, then AVERAGE across groups
        - Awareness/Management/Leadership: Score ONCE using all rows combined
        
        This can be overridden with scope: "per_group" in the JSON rules.
        """
        lines = []
        
        reference_question = questions[0]
        conditional_rules = reference_question.conditional_scoring_rules
        
        # Rules are always embedded as dict in sector-specific methods
        if conditional_rules:
            import json
            rules_json = json.dumps(conditional_rules, separators=(',', ':'))
            lines.append("    # Scoring rules (embedded for this sector)")
            lines.append(f"    rules = json.loads({repr(rules_json)})")
        else:
            lines.append("    rules = None")
        
        lines.append("    ")
        
        # Use rules structure for code generation
        default_rules = conditional_rules or {}
        
        # Part 1: Per-group disclosure scoring loop
        lines.append("    # Score disclosure per group (will be averaged)")
        lines.append("    group_disclosure_scores = []")
        lines.append("    _group_disclosure_tracking = []  # Always init so aggregate block can run")
        lines.append("    _group_ai_tracking = []  # Always init so aggregate block can run")
        lines.append("    ")

        # For multi-row groups (fixed rows forming one answer), make ONE AI call before
        # the disclosure loop so all rows are evaluated together as a single disclosure.
        needs_ai = (
            reference_question.disclosure_max_points is not None
            and reference_question.disclosure_points_if_answered is not None
            and reference_question.disclosure_max_points > reference_question.disclosure_points_if_answered
        )
        if needs_ai:
            max_ai_pts = (reference_question.disclosure_max_points or 0) - (reference_question.disclosure_points_if_answered or 0)
            lines.append("    # --- Single AI call for all rows combined (multi-row mode) ---")
            lines.append("    _global_ai_score = 0.0")
            lines.append("    _global_ai_explanation = ''")
            lines.append("    if gemini_client is not None:")
            lines.append("        _all_ai_answers = {}")
            lines.append("        for _g_rows in groups.values():")
            lines.append("            for _ai_row in _g_rows:")
            lines.append("                for _ai_q, _ai_v in _ai_row.items():")
            lines.append("                    if _ai_v is not None:")
            lines.append("                        _all_ai_answers[_ai_q] = _ai_v")
            lines.append("        try:")
            lines.append("            _ai_result = _evaluate_disclosure_quality_with_ai(_all_ai_answers, gemini_client)")
            lines.append("            _global_ai_score = _ai_result.get('score', 0.0) if isinstance(_ai_result, dict) else _ai_result")
            lines.append("            _global_ai_explanation = _ai_result.get('explanation', '') if isinstance(_ai_result, dict) else ''")
            lines.append("        except Exception as e:")
            lines.append('            print(f"DEBUG: AI evaluation failed for scoring group: {e}")')
            lines.append(f"        _group_ai_tracking.append({{")
            lines.append(f"            'rule_type': 'ai_scoring',")
            lines.append(f"            'rule_description': 'AI quality evaluation (all rows combined)',")
            lines.append(f"            'expected_points': {max_ai_pts},")
            lines.append(f"            'actual_points': _global_ai_score,")
            lines.append(f"            'achieved_full_points': _global_ai_score >= ({max_ai_pts} * 0.99),")
            lines.append(f"            'details': {{'explanation': _global_ai_explanation}} if _global_ai_explanation else {{}},")
            lines.append(f"            'group_name': 'all',")
            lines.append(f"            'executed': True")
            lines.append(f"        }})")
            lines.append("    # --- end single AI call ---")
            lines.append("    ")

        lines.append("    for group_name, group_rows in groups.items():")
        lines.append("        group_disclosure = 0.0")
        lines.append("        ")

        # Generate disclosure scoring inside the loop.
        # Pass use_pre_computed_ai=True so the generated code applies _global_ai_score
        # instead of calling Gemini again per group.
        disclosure_lines = self.disclosure_gen.generate(
            questions, default_rules or {}, reference_question,
            use_pre_computed_ai=needs_ai
        )
        lines.extend(disclosure_lines)
        
        lines.append("        ")
        lines.append("        group_disclosure_scores.append(group_disclosure)")
        lines.append("    ")

        # row_source penalty: add zero scores for expected-but-missing rows
        row_source = grouping_question.row_source
        if row_source:
            disclosure_base = grouping_question.disclosure_points_if_answered or 0.0
            lines.extend(self._build_row_source_penalty(row_source, disclosure_base))

        # Average disclosure scores
        lines.append("    # Average disclosure across all groups")
        lines.append("    avg_disclosure = sum(group_disclosure_scores) / len(group_disclosure_scores) if group_disclosure_scores else 0.0")
        lines.append("    ")
        lines.append("    # Aggregate disclosure explanation tracking across all groups")
        lines.append("    if '_group_disclosure_tracking' in locals() and _group_disclosure_tracking:")
        lines.append("        # Calculate aggregate totals for explanation")
        lines.append("        total_completed = sum(t.get('completed_rows', 0) for t in _group_disclosure_tracking)")
        lines.append("        total_visible = sum(t.get('total_rows', 0) for t in _group_disclosure_tracking)")
        lines.append("        aggregate_percentage = 100.0 * (total_completed / total_visible) if total_visible > 0 else 0.0")
        lines.append("        aggregate_points = sum(t.get('points_awarded', 0) for t in _group_disclosure_tracking)")
        lines.append("        num_groups = len(_group_disclosure_tracking)")
        lines.append("        # Store aggregated tracking (will be added to _explanation_tracking later)")
        lines.append("        _aggregated_disclosure_tracking = {")
        lines.append("            'rule_type': 'proportional_row_scoring',")
        lines.append("            'rule_description': 'Proportional scoring based on completed questions (averaged across groups)',")
        lines.append("            'completed_rows': total_completed,")
        lines.append("            'total_rows': total_visible,")
        lines.append("            'percentage': aggregate_percentage,")
        lines.append("            'points_awarded': avg_disclosure,")
        lines.append(f"            'max_points': {reference_question.disclosure_max_points or 0},")
        lines.append("            'actual_points': avg_disclosure,")
        lines.append(f"            'expected_points': {reference_question.disclosure_max_points or 0},")
        lines.append(f"            'achieved_full_points': avg_disclosure >= ({reference_question.disclosure_max_points or 0} * 0.99),")
        lines.append(f"            'reason': f'Proportional scoring: {{total_completed}}/{{total_visible}} questions answered ({{aggregate_percentage:.1f}}%) - averaged across {{num_groups}} group(s)' if total_visible > 0 else 'No visible questions',")
        lines.append("            'executed': True")
        lines.append("        }")
        lines.append("    else:")
        lines.append("        _aggregated_disclosure_tracking = None")
        lines.append("    ")
        
        # Part 2: Score awareness/management/leadership once using ALL rows
        lines.append("    # Score awareness/management/leadership once using all rows")
        lines.append("    all_rows = []")
        lines.append("    for group_rows in groups.values():")
        lines.append("        all_rows.extend(group_rows)")
        lines.append("    ")
        lines.append("    # Use all_rows as group_rows for global scoring")
        lines.append("    group_rows = all_rows")
        lines.append("    ")
        lines.append("    # Initialize scores (rule generators use group_ prefix)")
        lines.append("    group_awareness = 0.0")
        lines.append("    group_management = 0.0")
        lines.append("    group_leadership = 0.0")
        lines.append("    group_disclosure = avg_disclosure  # For prerequisite checks")
        lines.append("    ")
        
        # Initialize explanation tracking BEFORE generating category scoring
        # (category generators need it for tracking, especially prerequisites)
        lines.append("    # Initialize explanation tracking (needed by category generators)")
        lines.append("    from collections import defaultdict")
        lines.append("    _explanation_tracking = defaultdict(list)")
        lines.append("    ")
        
        # Generate awareness/management/leadership scoring (once, using all rows)
        # Always generate if category has max_points > 0 (defaults to proportional_cell_scoring if no rules)
        # Use default_rules for code generation structure
        awareness_rules = default_rules.get("awareness", {}) if default_rules else {}
        awareness_max = awareness_rules.get("max_points", 0) or reference_question.awareness_max_points or 0
        if awareness_max > 0:
            # Generate awareness scoring
            awareness_lines = self.category_gen.generate(
                questions, default_rules or {}, reference_question, "awareness"
            )
            # Dedent lines by 4 spaces (they're generated for inside a loop)
            awareness_lines = [line[4:] if line.startswith("        ") else line for line in awareness_lines]
            lines.extend(awareness_lines)
        
        management_rules = default_rules.get("management", {}) if default_rules else {}
        management_max = management_rules.get("max_points", 0) or reference_question.management_max_points or 0
        if management_max > 0:
            # Generate management scoring
            management_lines = self.category_gen.generate(
                questions, default_rules or {}, reference_question, "management"
            )
            management_lines = [line[4:] if line.startswith("        ") else line for line in management_lines]
            lines.extend(management_lines)
        
        leadership_rules = default_rules.get("leadership", {}) if default_rules else {}
        leadership_max = leadership_rules.get("max_points", 0) or reference_question.leadership_max_points or 0
        if leadership_max > 0:
            # Generate leadership scoring
            leadership_lines = self.category_gen.generate(
                questions, default_rules or {}, reference_question, "leadership"
            )
            leadership_lines = [line[4:] if line.startswith("        ") else line for line in leadership_lines]
            lines.extend(leadership_lines)

        # row_source: scale awareness/management/leadership by actual/expected row ratio
        if row_source:
            lines.extend(self._build_row_source_category_scaling())

        lines.append("    ")
        
        # Initialize _group_ai_tracking if not already initialized (for cases without AI scoring)
        lines.append("    # Initialize _group_ai_tracking if not already set")
        lines.append("    if '_group_ai_tracking' not in locals():")
        lines.append("        _group_ai_tracking = []")
        lines.append("    ")
        lines.append("    # Add aggregated disclosure tracking if available")
        lines.append("    if '_aggregated_disclosure_tracking' in locals() and _aggregated_disclosure_tracking:")
        lines.append("        _explanation_tracking['disclosure'].append(_aggregated_disclosure_tracking)")
        lines.append("    ")
        lines.append("    # Add aggregated AI tracking if available")
        lines.append("    if '_group_ai_tracking' in locals() and _group_ai_tracking:")
        lines.append("        # Aggregate AI scores across groups (average)")
        lines.append("        total_ai_points = sum(t.get('actual_points', 0) for t in _group_ai_tracking)")
        lines.append("        avg_ai_points = total_ai_points / len(_group_ai_tracking) if _group_ai_tracking else 0.0")
        lines.append("        max_ai_points = _group_ai_tracking[0].get('expected_points', 0) if _group_ai_tracking else 0.0")
        lines.append("        # Combine AI explanations from all groups")
        lines.append("        ai_explanations_combined = []")
        lines.append("        for t in _group_ai_tracking:")
        lines.append("            exp = t.get('details', {}).get('explanation', '')")
        lines.append("            if exp:")
        lines.append("                ai_explanations_combined.append(exp)")
        lines.append("        combined_explanation = ' '.join(ai_explanations_combined) if ai_explanations_combined else ''")
        lines.append("        # Add aggregated AI tracking to explanation tracking")
        lines.append("        _explanation_tracking['disclosure'].append({")
        lines.append("            'rule_type': 'ai_scoring',")
        lines.append("            'rule_description': 'AI quality evaluation (averaged across groups)',")
        lines.append("            'expected_points': max_ai_points,")
        lines.append("            'actual_points': avg_ai_points,")
        lines.append("            'achieved_full_points': avg_ai_points >= (max_ai_points * 0.99),")
        lines.append("            'details': {'explanation': combined_explanation} if combined_explanation else {},")
        lines.append("            'executed': True")
        lines.append("        })")
        lines.append("    ")
        lines.append("    # Return averaged disclosure + single awareness/management/leadership")
        lines.append("    result = {")
        lines.append('        "disclosure": avg_disclosure,')
        lines.append('        "awareness": group_awareness,')
        lines.append('        "management": group_management,')
        lines.append('        "leadership": group_leadership,')
        lines.append("    }")
        lines.append("    if ai_explanations:")
        lines.append('        result["ai_explanations"] = ai_explanations')
        lines.append("    # Return both scores and explanation tracking as a tuple (API expects this format)")
        lines.append("    return (result, _explanation_tracking)")
        lines.append("")
        
        return lines
    
    def _get_per_group_categories(self, rules: Dict) -> set:
        """Get set of categories that should be scored per-group (non-default)."""
        per_group_categories = set()
        
        if not rules:
            return per_group_categories
        
        for category in ["awareness", "management", "leadership"]:
            if category in rules:
                cat_rules = rules[category].get("rules", [])
                for rule in cat_rules:
                    if rule.get("scope") == "per_group":
                        per_group_categories.add(category)
                        break
        
        return per_group_categories
    
    def _build_per_group_scoring_loop(
        self,
        questions: List['QuestionSpec'],
        grouping_question: 'QuestionSpec'
    ) -> List[str]:
        """Build scoring loop for multi-answer multi-rows questions.
        
        Each group (Climate Change, Water, etc.) gets its own complete score
        for ALL categories (disclosure, awareness, management, leadership).
        
        Returns a dictionary keyed by group name.
        """
        lines = []
        
        reference_question = questions[0]
        conditional_rules = reference_question.conditional_scoring_rules
        
        # Rules are always embedded as dict in sector-specific methods
        if conditional_rules:
            import json
            rules_json = json.dumps(conditional_rules, separators=(',', ':'))
            lines.append("    # Scoring rules (embedded for this sector)")
            lines.append(f"    rules = json.loads({repr(rules_json)})")
        else:
            lines.append("    # No conditional scoring rules defined")
            lines.append("    rules = {}")
        
        lines.append("    ")
        
        # Use rules structure for code generation
        default_rules = conditional_rules or {}
        
        lines.append("    # Multi-answer mode: Score each group independently for ALL categories")
        lines.append("    group_scores = {}")
        lines.append("    # Initialize group-level tracking (populated by disclosure/AI per group when present)")
        lines.append("    _group_disclosure_tracking = []")
        lines.append("    _group_ai_tracking = []")
        lines.append("    ")
        lines.append("    for group_name, group_rows in groups.items():")
        lines.append("        # Initialize scores for this group")
        lines.append("        group_disclosure = 0.0")
        lines.append("        group_awareness = 0.0")
        lines.append("        group_management = 0.0")
        lines.append("        group_leadership = 0.0")
        lines.append("        ")
        
        # Initialize explanation tracking for this group (needed by category generators)
        lines.append("        # Initialize explanation tracking for this group")
        lines.append("        from collections import defaultdict")
        lines.append("        _explanation_tracking = defaultdict(list)")
        lines.append("        ")
        
        # Generate scoring logic for each group (always generate disclosure - default is proportional_cell_scoring)
        # use_pre_computed_ai=False: multi-answer groups get one Gemini call per group
        disclosure_lines = self.disclosure_gen.generate(
            questions, default_rules or {}, reference_question, use_pre_computed_ai=False
        )
        lines.extend(disclosure_lines)
        
        # Generate awareness/management/leadership only if rules exist
        if default_rules:
            awareness_lines = self.category_gen.generate(
                questions, default_rules, reference_question, "awareness"
            )
            lines.extend(awareness_lines)
            
            management_lines = self.category_gen.generate(
                questions, default_rules, reference_question, "management"
            )
            lines.extend(management_lines)
            
            leadership_lines = self.category_gen.generate(
                questions, default_rules, reference_question, "leadership"
            )
            lines.extend(leadership_lines)
        
        # Collect explanation tracking for this group (if any)
        lines.append("        if '_explanation_tracking' in locals():")
        lines.append("            if '_group_tracking' not in locals():")
        lines.append("                from collections import defaultdict")
        lines.append("                _group_tracking = defaultdict(lambda: defaultdict(list))")
        lines.append("            for category in ['awareness', 'management', 'leadership']:")
        lines.append("                if category in _explanation_tracking:")
        lines.append("                    for entry in _explanation_tracking[category]:")
        lines.append("                        entry_with_group = entry.copy()")
        lines.append("                        entry_with_group['group_name'] = group_name")
        lines.append("                        _group_tracking[category][group_name].append(entry_with_group)")
        
        # Store group scores
        lines.append("        ")
        lines.append("        group_scores[group_name] = {")
        lines.append('            "disclosure": group_disclosure,')
        lines.append('            "awareness": group_awareness,')
        lines.append('            "management": group_management,')
        lines.append('            "leadership": group_leadership,')
        lines.append("        }")
        lines.append("        # Add AI explanation if available")
        lines.append("        if group_name in ai_explanations:")
        lines.append("            group_scores[group_name]['ai_explanations'] = ai_explanations[group_name]")
        lines.append("            # Also add AI scores breakdown for reporting")
        lines.append("            if '_ai_score_disclosure' in ai_explanations[group_name]:")
        lines.append("                if 'ai_scores' not in group_scores[group_name]:")
        lines.append("                    group_scores[group_name]['ai_scores'] = {}")
        lines.append("                group_scores[group_name]['ai_scores']['disclosure'] = ai_explanations[group_name]['_ai_score_disclosure']")
        lines.append("    ")
        lines.append("    # Initialize explanation tracking for multi-answer mode")
        lines.append("    from collections import defaultdict")
        lines.append("    _explanation_tracking = defaultdict(list)")
        lines.append("    ")
        lines.append("    # Aggregate disclosure explanation tracking from all groups")
        lines.append("    if '_group_disclosure_tracking' in locals() and _group_disclosure_tracking:")
        lines.append("        # For each group's disclosure tracking, add to explanation tracking")
        lines.append("        for tracking_entry in _group_disclosure_tracking:")
        lines.append("            _explanation_tracking['disclosure'].append(tracking_entry)")
        lines.append("    ")
        lines.append("    # Aggregate AI explanation tracking from all groups")
        lines.append("    if '_group_ai_tracking' in locals() and _group_ai_tracking:")
        lines.append("        # For each group's AI tracking, add to explanation tracking")
        lines.append("        for tracking_entry in _group_ai_tracking:")
        lines.append("            _explanation_tracking['disclosure'].append(tracking_entry)")
        lines.append("    ")
        lines.append("    # Aggregate explanation tracking from all groups")
        lines.append("    if '_group_tracking' in locals() and _group_tracking:")
        lines.append("        # For each category, aggregate tracking across groups")
        lines.append("        for category in ['awareness', 'management', 'leadership']:")
        lines.append("            if category in _group_tracking:")
        lines.append("                # Collect all entries from all groups for this category")
        lines.append("                all_entries = []")
        lines.append("                for group_name, entries in _group_tracking[category].items():")
        lines.append("                    all_entries.extend(entries)")
        lines.append("                # If we have entries, add them to explanation tracking")
        lines.append("                if all_entries:")
        lines.append("                    # For multi-answer mode, include group context in explanations")
        lines.append("                    _explanation_tracking[category].extend(all_entries)")
        lines.append("    ")
        lines.append("    # Return both group_scores and explanation tracking as a tuple (API expects this format)")
        lines.append("    return (group_scores, _explanation_tracking)")
        lines.append("")
        
        return lines
