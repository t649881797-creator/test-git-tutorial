"""
Spreadsheet Parser

Parses CDP_scoring_questions.xlsx into QuestionSpec objects.
"""

import openpyxl
import json
from typing import List, Optional
from pathlib import Path
from .compiler_config import QuestionSpec


class SpreadsheetParser:
    """Parser for CDP scoring questions spreadsheet."""
    
    def __init__(self, spreadsheet_path: str):
        """
        Initialize the parser with the path to the Excel file.
        
        Args:
            spreadsheet_path: Path to CDP_scoring_questions.xlsx
        """
        self.spreadsheet_path = Path(spreadsheet_path)
        if not self.spreadsheet_path.exists():
            raise FileNotFoundError(f"Spreadsheet not found: {spreadsheet_path}")
        
        self.workbook = openpyxl.load_workbook(self.spreadsheet_path)
        self.worksheet = self.workbook.active
        
        # Column indices (0-based after reading header)
        self.columns = self._parse_header()
    
    def _parse_header(self) -> dict:
        """Parse the header row to get column indices."""
        header_row = list(self.worksheet.rows)[0]
        columns = {}
        for idx, cell in enumerate(header_row):
            if cell.value:
                columns[cell.value] = idx
        return columns
    
    def parse_all(self, scoring_group: Optional[str] = None) -> List[QuestionSpec]:
        """
        Parse all questions from the spreadsheet.
        
        Args:
            scoring_group: If provided, only parse questions from this scoring group
        
        Returns:
            List of QuestionSpec objects
        """
        questions = []
        
        # Skip header row
        for row in list(self.worksheet.rows)[1:]:
            # Check if row is empty
            if not row[self.columns['question_number']].value:
                continue
            
            # Skip questions marked as "not a graded question" in notes
            if 'notes' in self.columns:
                notes_value = row[self.columns['notes']].value
                if notes_value and 'not a graded question' in str(notes_value).lower():
                    continue
            
            question = self._parse_row(row)
            
            # Filter by scoring group if specified
            if scoring_group is not None:
                # Convert scoring_group to string for comparison
                row_group = str(question.scoring_group) if question.scoring_group else ""
                filter_group = str(scoring_group)
                
                if row_group != filter_group:
                    continue
            
            questions.append(question)
        
        # Post-processing: Ensure all questions in a scoring group have identical conditional_scoring_rules
        # Group questions by scoring_group
        if questions:
            from collections import defaultdict
            by_group = defaultdict(list)
            for q in questions:
                group_key = str(q.scoring_group) if q.scoring_group else "no_group"
                by_group[group_key].append(q)
            
            # For each group, propagate conditional_scoring_rules from first question to all
            for group_key, group_questions in by_group.items():
                if len(group_questions) <= 1:
                    continue  # Single question, nothing to propagate
                
                # Find the first question with conditional_scoring_rules
                group_rules = None
                for q in group_questions:
                    if q.conditional_scoring_rules:
                        group_rules = q.conditional_scoring_rules
                        break
                
                # If we found rules, apply them to all questions in the group
                if group_rules:
                    for q in group_questions:
                        if not q.conditional_scoring_rules:
                            q.conditional_scoring_rules = group_rules
        
        return questions
    
    def _parse_row(self, row) -> QuestionSpec:
        """Parse a single row into a QuestionSpec."""
        
        # Helper to get cell value
        def get_value(col_name, default=None):
            if col_name not in self.columns:
                return default
            value = row[self.columns[col_name]].value
            return value if value is not None else default
        
        # Helper to parse float
        def get_float(col_name, default=0.0):
            value = get_value(col_name, default)
            try:
                return float(value) if value is not None else default
            except (ValueError, TypeError):
                return default
        
        # Helper to parse JSON
        def get_json(col_name, default=None):
            value = get_value(col_name)
            if not value:
                return default
            
            # If already a list or dict, return it
            if isinstance(value, (list, dict)):
                return value
            
            # Try to parse as JSON
            try:
                return json.loads(value)
            except (json.JSONDecodeError, TypeError):
                return default
        
        # Parse classification options
        classification_options = get_json('classification_options')
        
        # Parse conditional scoring rules
        conditional_scoring_rules = get_json('conditional_scoring_rules')
        
        # Create QuestionSpec
        question = QuestionSpec(
            question_number=str(get_value('question_number', '')),  # Ensure string
            question_text=get_value('question_text', ''),
            
            # Max points
            disclosure_max_points=get_float('disclosure_max_points', 0.0),
            awareness_max_points=get_float('awareness_max_points', 0.0),
            management_max_points=get_float('management_max_points', 0.0),
            leadership_max_points=get_float('leadership_max_points', 0.0),
            
            # Points if answered
            disclosure_points_if_answered=get_float('disclosure_points_if_answered', 0.0),
            awareness_points_if_answered=get_float('awareness_points_if_answered', 0.0),
            management_points_if_answered=get_float('management_points_if_answered', 0.0),
            leadership_points_if_answered=get_float('leadership_points_if_answered', 0.0),
            
            # Metadata
            dependencies=get_value('dependencies'),
            question_type=get_value('question_type', 'classification'),
            scoring_group=str(get_value('scoring_group', '')),  # Ensure string
            conditional_on=get_value('conditional_on'),
            
            # Parsed JSON
            classification_options=classification_options,
            conditional_scoring_rules=conditional_scoring_rules,
            
            # Notes
            notes=get_value('notes'),

            # Row source: parent question whose answers determine the rows of this table
            row_source=get_value('row_source'),
        )

        return question
    
    def get_scoring_groups(self) -> List[str]:
        """Get all unique scoring groups in the spreadsheet."""
        groups = set()
        
        for row in list(self.worksheet.rows)[1:]:
            if not row[self.columns['question_number']].value:
                continue
            
            group_value = row[self.columns['scoring_group']].value
            if group_value:
                groups.add(str(group_value))
        
        return sorted(list(groups))

    @staticmethod
    def is_row_based_scoring_group(questions: List[QuestionSpec]) -> bool:
        """
        Detect if a scoring group uses row-based (table) structure.
        
        Row-based questions are identified by conditional patterns like "2.2.2.1.Risk != NULL"
        where the suffix after the question number (.Risk, .Opportunity, etc.) indicates
        checking if a row exists.
        
        "Fixed rows" question type means each answer selection creates a new row
        with its own complete set of follow-up questions.
        
        Example: If question 2.2.2.1 has ["Climate change", "Water"], it creates:
        - Row 1 for Climate change with 2.2.2.2 through 2.2.2.16
        - Row 2 for Water with its own 2.2.2.2 through 2.2.2.16
        
        Args:
            questions: List of questions in the scoring group
            
        Returns:
            True if this is a row-based scoring group
        """
        if not questions:
            return False
        
        first_question = questions[0]
        first_q_num = first_question.question_number

        # Check if the first question has "multi-row" type
        if first_question.question_type and first_question.question_type == "multi-row":
            return True

        # Check if the first question has row_source (fixed rows populated by parent question)
        if first_question.row_source:
            return True

        # Check conditional_on for row-based patterns in subsequent questions
        # Pattern: "X.Y.Z.SomeSuffix != NULL" where SomeSuffix is after the question number
        for q in questions[1:]:
            if q.conditional_on and first_q_num in q.conditional_on:
                # Extract what comes after the question number
                # e.g., "2.2.2.1.Risk != NULL" -> ".Risk != NULL"
                after_q_num = q.conditional_on.split(first_q_num, 1)[1]
                
                # Check if there's a dot followed by text before the comparison operator
                # This indicates a row reference like ".Risk" or ".Opportunity"
                if after_q_num.startswith('.') and len(after_q_num) > 1:
                    # Has something like ".Risk", ".Opportunity", etc.
                    return True
        
        return False

